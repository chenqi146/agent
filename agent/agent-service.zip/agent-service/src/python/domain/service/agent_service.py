from typing import List, Optional, Dict, Any, AsyncGenerator, Tuple
from datetime import datetime
import uuid
import json
import asyncio
from fastapi.responses import StreamingResponse

from infrastructure.common.logging.logging import logger
from infrastructure.common.error.errcode import ErrorCode
from infrastructure.config.sys_config import SysConfig
from infrastructure.persistences.mysql_persistence import MysqlPersistence
from infrastructure.repositories.agent_repository import AgentRepository
from interfaces.dto.chat_dto import (
    ChatConversationDTO, ChatMessageDTO, MessageRole, ContentType,
    ChatStreamRequest, ChatHistoryResponse, ChatConversationResponse,
    ChatMessageAttachmentDTO
)
from openai import AsyncOpenAI

@logger()
class AgentService:
    def __init__(self):
        self.config = SysConfig()
        self.agent_config = self.config.get_agent_config()
        self.mysql_config = self.config.get_system_config().get('persistence', {}).get('mysql', {})
        
        self.persistence = MysqlPersistence(
            host=self.mysql_config.get('host'),
            port=self.mysql_config.get('port'),
            username=self.mysql_config.get('username'),
            password=self.mysql_config.get('password'),
            database=self.mysql_config.get('database')
        )
        self.repository = AgentRepository(self.persistence)
        
        # Initialize LLM Client
        system_config = self.config.get_system_config()
        vllm_config = system_config.get('vllm', {})
        llm_root_config = vllm_config.get('llm', {})
        
        llm_type = llm_root_config.get('type', 'hsyq')
        llm_config = llm_root_config.get(llm_type, {})
        
        self.llm_client = AsyncOpenAI(
            api_key=llm_config.get('key'),
            base_url=llm_config.get('base_url')
        )
        self.model = llm_config.get('model', 'doubao-seed-1-8-251228')
        
        # Track running generation tasks
        self._running_tasks: Dict[str, bool] = {}

    def stop_generation(self, conversation_id: str):
        """Stop generation for a specific conversation"""
        if conversation_id in self._running_tasks:
            self._running_tasks[conversation_id] = False
            self.log.info(f"Stop signal received for conversation {conversation_id}")
            return True
        return False

    def _format_time(self, dt):
        if not dt:
            return None
        if isinstance(dt, str):
            return dt
        return dt.strftime('%Y-%m-%d %H:%M:%S')

    def _update_history_index(self, user_id: int, conversation_id: str, message: str, attachments: List[Dict] = None):
        try:
            # 1. Get conversation title
            err, conv = self.repository.get_conversation_by_id(conversation_id)
            if err != ErrorCode.SUCCESS or not conv:
                if message:
                    title = message[:20]
                elif attachments:
                    title = f"File: {attachments[0].get('fileName', 'Attachment')}"
                else:
                    title = "New Conversation"
            else:
                title = conv['title']
                
            # 2. Construct preview
            if message:
                preview = message[:500] # truncate
            elif attachments:
                file_names = [att.get('fileName', 'file') for att in attachments]
                preview = f"[Attachments: {', '.join(file_names)}]"
            else:
                preview = ""
            
            # 3. Save index
            self.repository.save_history_index({
                "user_id": user_id,
                "conversation_id": conversation_id,
                "search_content": f"{title} {preview}",
                "last_message_preview": preview,
                "created_at": datetime.now()
            })
        except Exception as e:
            self.log.error(f"Failed to update history index: {e}")

    async def get_history(self, user_id: int) -> Tuple[ErrorCode, Optional[ChatHistoryResponse]]:
        err, conversations = self.repository.get_conversations(user_id)
        if err != ErrorCode.SUCCESS:
            return err, None
            
        dtos = []
        for conv in conversations:
            dtos.append(ChatConversationDTO(
                id=conv['id'],
                conversationId=conv['conversation_id'],
                userId=conv['user_id'],
                title=conv['title'],
                modelName=conv['model_name'],
                isPinned=bool(conv['is_pinned']),
                messageCount=conv['message_count'],
                tokenCount=conv['token_count'],
                lastMessageTime=self._format_time(conv['last_message_time']),
                isDeleted=bool(conv['is_deleted']),
                createdAt=self._format_time(conv['created_at']),
                updatedAt=self._format_time(conv['updated_at'])
            ))
            
        return ErrorCode.SUCCESS, ChatHistoryResponse(conversations=dtos)

    async def get_conversation(self, conversation_id: str) -> Tuple[ErrorCode, Optional[ChatConversationResponse]]:
        err, conv = self.repository.get_conversation_by_id(conversation_id)
        if err != ErrorCode.SUCCESS or not conv:
            return ErrorCode.RESOURCE_NOT_FOUND, None
            
        err, messages = self.repository.get_messages(conversation_id)
        if err != ErrorCode.SUCCESS:
            return err, None
            
        # Get attachments
        message_ids = [msg['message_id'] for msg in messages]
        _, attachments = self.repository.get_attachments_by_message_ids(message_ids)
        att_map = {}
        if attachments:
            for att in attachments:
                mid = att['message_id']
                if mid not in att_map:
                    att_map[mid] = []
                att_map[mid].append(ChatMessageAttachmentDTO(
                    id=att['id'],
                    messageId=att['message_id'],
                    fileName=att['file_name'],
                    fileType=att['file_type'],
                    fileSize=att['file_size'],
                    fileUrl=att['file_url'],
                    thumbnailUrl=att['thumbnail_url'],
                    storageType=att['storage_type'],
                    metadata=json.loads(att['metadata']) if att['metadata'] and isinstance(att['metadata'], str) else att.get('metadata')
                ))

        msg_dtos = []
        for msg in messages:
            mid = msg['message_id']
            msg_dtos.append(ChatMessageDTO(
                id=str(msg['id']),
                messageId=msg['message_id'],
                conversationId=msg['conversation_id'],
                parentMessageId=msg['parent_message_id'],
                role=MessageRole(msg['role']),
                content=msg['content'],
                contentType=ContentType(msg['content_type']),
                modelName=msg['model_name'],
                tokenCount=msg['token_count'],
                isContext=bool(msg['is_context']),
                metadata=msg['metadata'] if isinstance(msg['metadata'], dict) else None,
                createdAt=self._format_time(msg['created_at']),
                seqNo=msg['seq_no'],
                attachments=att_map.get(mid, [])
            ))
        
        conv_dto = ChatConversationDTO(
            id=conv['id'],
            conversationId=conv['conversation_id'],
            userId=conv['user_id'],
            title=conv['title'],
            modelName=conv['model_name'],
            isPinned=bool(conv['is_pinned']),
            messageCount=conv['message_count'],
            tokenCount=conv['token_count'],
            lastMessageTime=self._format_time(conv['last_message_time']),
            isDeleted=bool(conv['is_deleted']),
            createdAt=self._format_time(conv['created_at']),
            updatedAt=self._format_time(conv['updated_at'])
        )

        return ErrorCode.SUCCESS, ChatConversationResponse(
            conversation=conv_dto,
            messages=msg_dtos
        )

    async def delete_conversation(self, conversation_id: str) -> Tuple[ErrorCode, Any]:
        return self.repository.delete_conversation(conversation_id)

    async def clear_history(self, user_id: int) -> Tuple[ErrorCode, Any]:
        return self.repository.clear_history(user_id)

    async def stream_chat(self, request: ChatStreamRequest, user_id: int) -> AsyncGenerator[str, None]:
        conversation_id = request.conversationId
        
        # 1. Create conversation if not exists
        if not conversation_id:
            conversation_id = str(uuid.uuid4())
            title = request.message[:20] if request.message else "New Conversation"
            if not request.message and request.attachments:
                title = f"File: {request.attachments[0].get('fileName')}"
                
            err, _ = await asyncio.to_thread(self.repository.create_conversation, {
                "conversation_id": conversation_id,
                "user_id": user_id,
                "title": title,
                "model_name": self.model,
                "created_at": datetime.now(),
                "updated_at": datetime.now(),
                "last_message_time": datetime.now()
            })
            if err != ErrorCode.SUCCESS:
                yield f"data: {json.dumps({'error': 'Failed to create conversation'})}\n\n"
                return

        # 2. Save user message
        user_msg_id = request.messageId or str(uuid.uuid4())
        
        # Mark conversation as running
        self._running_tasks[conversation_id] = True
        
        await asyncio.to_thread(self.repository.save_message, {
            "message_id": user_msg_id,
            "conversation_id": conversation_id,
            "user_id": user_id,
            "role": MessageRole.USER,
            "content": request.message or "",
            "model_name": self.model,
            "seq_no": (await asyncio.to_thread(self.repository.get_last_seq_no, conversation_id)) + 1,
            "created_at": datetime.now()
        })
        
        if request.attachments:
            for att in request.attachments:
                await asyncio.to_thread(self.repository.save_attachment, {
                    "message_id": user_msg_id,
                    "user_id": user_id,
                    "conversation_id": conversation_id,
                    "file_name": att.get("fileName"),
                    "file_type": att.get("fileType"),
                    "file_size": att.get("fileSize"),
                    "file_url": att.get("fileUrl"),
                    "thumbnail_url": att.get("thumbnailUrl"),
                    "storage_type": att.get("storageType", "local"),
                    "metadata": json.dumps(att.get("metadata")) if att.get("metadata") else None,
                    "created_at": datetime.now()
                })
        
        # Update history index for user message
        await asyncio.to_thread(self._update_history_index, user_id, conversation_id, request.message, request.attachments)
        
        # 3. Get context (last N messages)
        _, history_msgs = await asyncio.to_thread(self.repository.get_messages, conversation_id)
        
        # Limit context to last 20 messages to avoid token overflow
        if history_msgs and len(history_msgs) > 20:
            history_msgs = history_msgs[-20:]
            
        messages_context = []
        for msg in history_msgs:
            msg_content = msg['content']
            
            # If current message (user) has attachments and empty content, let's inject a prompt
            if msg['message_id'] == user_msg_id and not msg['content'] and request.attachments:
                file_names = ", ".join([att.get("fileName") for att in request.attachments])
                msg_content = f"I have uploaded files: {file_names}. Please analyze them."

            if msg_content:
                messages_context.append({
                    "role": msg['role'],
                    "content": msg_content
                })
            
        # 4. Call LLM Stream
        try:
            # Yield conversation ID immediately so frontend knows it
            yield f"data: {json.dumps({'conversationId': conversation_id})}\n\n"

            stream = await self.llm_client.chat.completions.create(
                model=self.model,
                messages=messages_context,
                stream=True
            )
            
            assistant_response = ""
            
            async for chunk in stream:
                # Check stop flag
                if not self._running_tasks.get(conversation_id, False):
                    self.log.info(f"Generation stopped for {conversation_id}")
                    # yield f"data: {json.dumps({'error': 'Stopped by user', 'code': 'STOPPED'})}\n\n"
                    # Don't yield error, just stop. Frontend handles it.
                    break

                if chunk.choices[0].delta.content:
                    content = chunk.choices[0].delta.content
                    assistant_response += content
                    yield f"data: {json.dumps({'content': content})}\n\n"
            
            # 5. Save assistant message (even if stopped)
            await asyncio.to_thread(self.repository.save_message, {
                "message_id": str(uuid.uuid4()),
                "conversation_id": conversation_id,
                "user_id": user_id,
                "role": MessageRole.ASSISTANT,
                "content": assistant_response,
                "model_name": self.model,
                "seq_no": (await asyncio.to_thread(self.repository.get_last_seq_no, conversation_id)) + 1,
                "created_at": datetime.now()
            })
            
            # Update conversation last message time
            await asyncio.to_thread(self.repository.update_conversation, conversation_id, {
                "last_message_time": datetime.now()
            })
            
            # Update history index for assistant message
            await asyncio.to_thread(self._update_history_index, user_id, conversation_id, assistant_response)
            
            # Signal done if not stopped (or always?)
            # If stopped, we might not want to send [DONE] if frontend uses it to close.
            # But here we just break.
            yield "data: [DONE]\n\n"
            
        except Exception as e:
            self.log.error(f"Stream chat error: {e}")
            yield f"data: {json.dumps({'error': str(e)})}\n\n"
        finally:
            if conversation_id in self._running_tasks:
                del self._running_tasks[conversation_id]

    async def chat_message(self, request: ChatStreamRequest, user_id: int) -> Tuple[ErrorCode, Optional[Dict]]:
        conversation_id = request.conversationId
        
        # 1. Create conversation if not exists
        if not conversation_id:
            conversation_id = str(uuid.uuid4())
            title = request.message[:20] if request.message else "New Conversation"
            if not request.message and request.attachments:
                title = f"File: {request.attachments[0].get('fileName')}"
                
            err, _ = await asyncio.to_thread(self.repository.create_conversation, {
                "conversation_id": conversation_id,
                "user_id": user_id,
                "title": title,
                "model_name": self.model,
                "created_at": datetime.now(),
                "updated_at": datetime.now(),
                "last_message_time": datetime.now()
            })
            if err != ErrorCode.SUCCESS:
                return err, None

        # 2. Save user message
        user_msg_id = request.messageId or str(uuid.uuid4())
        await asyncio.to_thread(self.repository.save_message, {
            "message_id": user_msg_id,
            "conversation_id": conversation_id,
            "user_id": user_id,
            "role": MessageRole.USER,
            "content": request.message or "",
            "model_name": self.model,
            "seq_no": (await asyncio.to_thread(self.repository.get_last_seq_no, conversation_id)) + 1,
            "created_at": datetime.now()
        })
        
        if request.attachments:
            for att in request.attachments:
                await asyncio.to_thread(self.repository.save_attachment, {
                    "message_id": user_msg_id,
                    "user_id": user_id,
                    "conversation_id": conversation_id,
                    "file_name": att.get("fileName"),
                    "file_type": att.get("fileType"),
                    "file_size": att.get("fileSize"),
                    "file_url": att.get("fileUrl"),
                    "thumbnail_url": att.get("thumbnailUrl"),
                    "storage_type": att.get("storageType", "local"),
                    "metadata": json.dumps(att.get("metadata")) if att.get("metadata") else None,
                    "created_at": datetime.now()
                })

        # Update history index for user message
        await asyncio.to_thread(self._update_history_index, user_id, conversation_id, request.message, request.attachments)
        
        # 3. Get context
        _, history_msgs = await asyncio.to_thread(self.repository.get_messages, conversation_id)
        
        # Limit context to last 20 messages
        if history_msgs and len(history_msgs) > 20:
            history_msgs = history_msgs[-20:]
            
        messages_context = []
        for msg in history_msgs:
            msg_content = msg['content']
            if msg['message_id'] == user_msg_id and not msg['content'] and request.attachments:
                 file_names = ", ".join([att.get("fileName") for att in request.attachments])
                 msg_content = f"I have uploaded files: {file_names}. Please analyze them."
            
            if msg_content:
                messages_context.append({
                    "role": msg['role'],
                    "content": msg_content
                })
            
        # 4. Call LLM
        try:
            response = await self.llm_client.chat.completions.create(
                model=self.model,
                messages=messages_context,
                stream=False
            )
            
            assistant_response = response.choices[0].message.content
            
            # 5. Save assistant message
            await asyncio.to_thread(self.repository.save_message, {
                "message_id": str(uuid.uuid4()),
                "conversation_id": conversation_id,
                "user_id": user_id,
                "role": MessageRole.ASSISTANT,
                "content": assistant_response,
                "model_name": self.model,
                "seq_no": (await asyncio.to_thread(self.repository.get_last_seq_no, conversation_id)) + 1,
                "created_at": datetime.now()
            })
            
            # Update conversation last message time
            await asyncio.to_thread(self.repository.update_conversation, conversation_id, {
                "last_message_time": datetime.now()
            })
            
            # Update history index for assistant message
            await asyncio.to_thread(self._update_history_index, user_id, conversation_id, assistant_response)
            
            return ErrorCode.SUCCESS, {
                "conversationId": conversation_id,
                "content": assistant_response
            }
            
        except Exception as e:
            self.log.error(f"LLM Error: {e}")
            return ErrorCode.INTERNAL_ERROR, None

    async def handle_ping(self):
        return ErrorCode.SUCCESS, {"status": "ok"}
