import asyncio
import json
import time
from typing import Tuple, List, Dict, Any, Optional
from io import BytesIO
from datetime import timedelta
from urllib.parse import quote

from minio import Minio
from qdrant_client.http import models as rest

from infrastructure.common.logging.logging import logger
from infrastructure.common.error.errcode import ErrorCode
from infrastructure.config.sys_config import SysConfig
from infrastructure.repositories.rag_repository import RagRepository
from infrastructure.client.embedding_client import EmbeddingClient
from infrastructure.client.redis_client import RedisTemplete
from infrastructure.persistences.qdrant_persistence import QDrantPersistence
from interfaces.dto.rag_dto import (
    KnowledgeBaseCreateRequest,
    KnowledgeBaseUpdateRequest,
    KnowledgeBaseIdRequest,
    KnowledgeBaseListRequest,
    KnowledgeBaseInfo,
    KnowledgeBasePage,
    KnowledgeBaseStatus,
    KnowledgeBaseType,
    RagQueryRequest,
    RagQueryAnswer,
    FileVectorizationStatusRequest,
    FileIdWithKbRequest,
    FileUpdateStatusRequest,
    FileVectorizationStatusResponse,
    KnowledgeItemListRequest,
    KnowledgeItemInfo,
)


@logger()
class RagService:
    """
    RAG 领域服务：知识库元数据（MySQL）+ 文档向量（Qdrant）+ 知识嵌入（vllm-application Embedding）。
    """

    def __init__(self, config: SysConfig, mysql_client=None, qdrant_client=None, minio_client=None):
        self.config = config
        self.repo = RagRepository(config, mysql_client)
        
        # 接收客户端实例
        self._mysql = mysql_client
        self._qdrant = qdrant_client
        self._minio_client = minio_client

        # vllm-application Embedding 客户端（知识嵌入）
        embedding_base_url = config.get_vllm_embedding_base_url()
        embedding_api_key = config.get_vllm_embedding_api_key()
        self._embedding_client = (
            EmbeddingClient(embedding_base_url,timeout=1800, api_key=embedding_api_key)
            if embedding_base_url
            else None
        )
        if self._embedding_client and self._embedding_client.is_available():
            self.log.info("RagService: EmbeddingClient (vllm) enabled for knowledge embedding")

        # 支持的文件类型配置
        self._supported_file_types = config.get_supported_file_types()
        self.log.info(f"RagService: Supported file types: {sorted(self._supported_file_types)}")

        # Qdrant 用于存储 RAG 文档向量
        system_cfg = config.get_system_config() or {}
        persistence_cfg = system_cfg.get("persistence", {}) or {}
        qdrant_cfg = persistence_cfg.get("qdrant", {}) or {}
        self._vector_dim = int(qdrant_cfg.get("vector_dim", 512))
        self._rag_collection = qdrant_cfg.get("collection", "pg_agent_application_collection")
        
        # 使用传入的qdrant_client，如果没有则保持原有的初始化方式作为兼容
        if qdrant_client:
            self._qdrant = qdrant_client
            self.log.info(f"RagService: Using injected Qdrant client for collection {self._rag_collection}")
        else:
            self._qdrant: Optional[QDrantPersistence] = None
            try:
                host = qdrant_cfg.get("host", "127.0.0.1")
                port = int(qdrant_cfg.get("port", 6333))
                api_key = qdrant_cfg.get("api_key") or None
                self._qdrant = QDrantPersistence(
                    url=f"http://{host}:{port}",
                    api_key=api_key,
                    timeout=30.0,
                )
                self._qdrant.vector_size = self._vector_dim
                self._qdrant.init_collection(
                    self._rag_collection,
                    vectors_config=rest.VectorParams(
                        size=self._vector_dim,
                        distance=rest.Distance.COSINE,
                    ),
                )
                self.log.info(f"RagService: Qdrant RAG collection {self._rag_collection} (dim={self._vector_dim})")
            except Exception as e:
                self.log.warning(f"RagService: Qdrant init skipped: {e}")

        # 向量化进度使用 RedisTemplete（封装好的 Redis），供前端轮询 /file/status 获取实时进度
        self._rag_progress_prefix = "rag:file:progress:"
        self._rag_progress_ttl = 86400  # 24 小时
        if RedisTemplete.is_init:
            self.log.info("RagService: 向量化进度将写入 Redis（RedisTemplete），前端轮询 /file/status 可获取实时进度")
        else:
            self.log.info("RagService: RedisTemplete 未初始化，向量化进度仅通过 MySQL 更新，前端轮询仍可获取进度（按批更新）")

        # MinIO 用于读取已上传文件内容（用于 .txt 解析后做嵌入）
        minio_cfg = persistence_cfg.get("minio", {}) or {}
        self._minio_bucket = minio_cfg.get("bucket", "pg-agent-rag-files")
        
        # 使用传入的minio_client，如果没有则保持原有的初始化方式作为兼容
        if minio_client:
            self._minio_client = minio_client
            self.log.info(f"RagService: Using injected MinIO client for bucket {self._minio_bucket}")
        else:
            self._minio_client: Optional[Minio] = None
            try:
                endpoint = minio_cfg.get("endpoint", "127.0.0.1:9000")
                self._minio_client = Minio(
                    endpoint,
                    access_key=minio_cfg.get("access_key", "admin"),
                    secret_key=minio_cfg.get("secret_key", "admin123"),
                    secure=bool(minio_cfg.get("secure", False)),
                )
                self.log.info(f"RagService: MinIO client initialized for bucket {self._minio_bucket}")
            except Exception as e:
                self.log.warning(f"RagService: MinIO client init skipped: {e}")

        self.log.info("RagService initialized with RagRepository")

    # ============== 工具方法 ==============

    def _map_status_from_db(self, status_val: int) -> KnowledgeBaseStatus:
        """
        将 rag_tbl.status (0/1) 映射为枚举：
        - 1 -> ENABLED
        - 0 -> DISABLED
        """
        return KnowledgeBaseStatus.ENABLED if status_val == 1 else KnowledgeBaseStatus.DISABLED

    def _map_status_to_db(self, status: KnowledgeBaseStatus) -> int:
        """
        将枚举映射为 rag_tbl.status：
        - ENABLED / BUILDING -> 1
        - DISABLED -> 0
        """
        if status == KnowledgeBaseStatus.DISABLED:
            return 0
        return 1

    def _map_type_from_db(self, type_str: str) -> KnowledgeBaseType:
        try:
            return KnowledgeBaseType(type_str)
        except Exception:
            return KnowledgeBaseType.DOCUMENT

    def _row_to_kb(self, row: Dict[str, Any]) -> KnowledgeBaseInfo:
        """将 rag_tbl 行记录映射为 DTO"""
        create_time = row.get("create_time")
        update_time = row.get("update_time")
        created_at_ms = (
            int(create_time.timestamp() * 1000) if create_time is not None else 0
        )
        updated_at_ms = (
            int(update_time.timestamp() * 1000) if update_time is not None else 0
        )

        return KnowledgeBaseInfo(
            id=row.get("id"),
            name=row.get("rag_name", ""),
            kb_type=self._map_type_from_db(row.get("type", "document")),
            status=self._map_status_from_db(int(row.get("status", 1))),
            created_at=created_at_ms,
            updated_at=updated_at_ms,
            file_capacity=int(row.get("file_capacity", 0) or 0),
            file_count=int(row.get("file_count", 0) or 0),
            binding_user=int(row.get("binding_user_id", 0) or 0),
        )

    # ============== 知识嵌入（vllm-application Embedding + Qdrant） ==============

    def _rag_progress_key(self, file_id: int) -> str:
        return f"{self._rag_progress_prefix}{file_id}"

    def set_rag_file_progress(
        self,
        file_id: int,
        embedding_process: int,
        embedding_progress: float = 0.0,
        file_char_count: int = 0,
        file_embedding_offset: int = 0,
        error_message: Optional[str] = None,
    ) -> None:
        """写入 Redis（RedisTemplete）：当前文件的向量化进度，供前端轮询。value 中含 file_id 便于 Redis 客户端识别编号。"""
        if not RedisTemplete.is_init:
            return
        try:
            data = {
                "file_id": file_id,
                "embedding_process": embedding_process,
                "embedding_progress": embedding_progress,
                "file_char_count": file_char_count,
                "file_embedding_offset": file_embedding_offset,
            }
            if error_message:
                data["error_message"] = error_message
            key = self._rag_progress_key(file_id)
            RedisTemplete.set(key, json.dumps(data), self._rag_progress_ttl)
        except Exception as e:
            self.log.warning(f"set_rag_file_progress failed: {e}")

    def clear_rag_file_progress(self, file_id: int) -> None:
        """文件完成后清理对应的 Redis 进度信息。"""
        if not RedisTemplete.is_init:
            self.log.warning(f"clear rag file process progress failure: RedisTemplete not initialized")
            return
        try:
            key = self._rag_progress_key(file_id)
            RedisTemplete.delete(key)
        except Exception as e:
            self.log.warning(f"clear_rag_file_progress failed: {e}")

    def cleanup_file_resources(
        self,
        kb_id: int,
        file_id: int,
        object_name: Optional[str] = None,
        bucket: Optional[str] = None,
    ) -> None:
        """
        清理单个文件相关资源：
        - Redis 进度
        - Qdrant 向量（按 file_id）
        - MinIO 对象
        - MySQL rag_file_tbl 记录
        """
        # Redis
        self.clear_rag_file_progress(file_id)

        # Qdrant 向量
        if self._qdrant:
            try:
                filter_condition = rest.Filter(
                    must=[
                        rest.FieldCondition(
                            key="file_id",
                            match=rest.MatchAny(any=[file_id]),
                        )
                    ]
                )
                err_del, n_pts = self._qdrant.delete(
                    filter=filter_condition,
                    collection_name=self._rag_collection,
                )
                if err_del != ErrorCode.SUCCESS:
                    self.log.warning(f"cleanup_file_resources: Qdrant delete failed err={err_del} for kb_id={kb_id}, file_id={file_id}")
                else:
                    self.log.info(f"cleanup_file_resources: Qdrant deleted {n_pts} points for kb_id={kb_id}, file_id={file_id}")
            except Exception as e:
                self.log.warning(f"cleanup_file_resources: Qdrant delete exception for kb_id={kb_id}, file_id={file_id}: {e}")

        # MinIO 对象
        obj_name = object_name
        if not obj_name:
            try:
                err_row, row = self.repo.get_file_by_id(file_id)
                if err_row == ErrorCode.SUCCESS and row and row.get("file_path"):
                    obj_name = row.get("file_path")
            except Exception:
                obj_name = None
        if obj_name and self._minio_client:
            try:
                b = bucket or self._minio_bucket
                self._minio_client.remove_object(b, obj_name)
                self.log.info(f"cleanup_file_resources: MinIO removed object '{obj_name}' for kb_id={kb_id}, file_id={file_id}")
            except Exception as e:
                self.log.warning(f"cleanup_file_resources: MinIO remove_object exception for '{obj_name}': {e}")

        # MySQL 文件记录
        try:
            err_del_file, _ = self.repo.delete_file_by_id(file_id)
            if err_del_file != ErrorCode.SUCCESS:
                self.log.warning(f"cleanup_file_resources: delete_file_by_id failed err={err_del_file} for kb_id={kb_id}, file_id={file_id}")
        except Exception as e:
            self.log.warning(f"cleanup_file_resources: delete_file_by_id exception for kb_id={kb_id}, file_id={file_id}: {e}")

    def get_rag_file_progress(self, file_id: int) -> Optional[Dict[str, Any]]:
        """从 Redis（RedisTemplete）读取文件向量化进度；无则返回 None。"""
        if not RedisTemplete.is_init:
            return None
        try:
            key = self._rag_progress_key(file_id)
            val = RedisTemplete.get(key)
            if val:
                return json.loads(val) if isinstance(val, str) else json.loads(val.decode("utf-8"))
        except Exception as e:
            self.log.warning(f"get_rag_file_progress failed: {e}")
        return None

    def embed_texts(
        self,
        texts: List[str],
        dimensions: Optional[int] = None,
    ) -> Tuple[ErrorCode, List[List[float]]]:
        """
        调用 vllm-application 将文本列表转为向量。
        dimensions 不传时使用配置的 vector_dim（与 Qdrant 一致）。
        """
        if not self._embedding_client or not self._embedding_client.is_available():
            self.log.warning("embed_texts: EmbeddingClient not available")
            return ErrorCode.SERVICE_UNAVAILABLE, []
        dim = dimensions if dimensions is not None else self._vector_dim
        return self._embedding_client.embed(texts, dimensions=dim)

    @staticmethod
    def _chunk_text(text: str, chunk_size: int = 500, overlap: int = 50) -> List[str]:
        """简单按字符数切分，overlap 为重叠长度。"""
        if not text or chunk_size <= 0:
            return []
        text = text.strip()
        if not text:
            return []
        step = max(1, chunk_size - overlap)
        chunks = []
        for i in range(0, len(text), step):
            chunk = text[i : i + chunk_size]
            if chunk:
                chunks.append(chunk)
        return chunks

    def index_chunks_for_file(
        self,
        kb_id: int,
        file_id: int,
        binding_user_id: int,
        chunks: List[str],
        file_char_count: int = 0,
        batch_size: int = 20,
    ) -> ErrorCode:
        """
        将文档分块向量化并写入 Qdrant。若 file_char_count > 0 则按批处理并写入 Redis 进度。
        payload: rag_id, file_id, chunk_index, text, binding_user_id
        """
        if not chunks:
            return ErrorCode.SUCCESS
        if not self._qdrant:
            self.log.warning("index_chunks_for_file: Qdrant not available")
            return ErrorCode.SERVICE_UNAVAILABLE
        total_chars = sum(len(c) for c in chunks)
        use_progress = file_char_count > 0 and RedisTemplete.is_init
        offset_chars = 0
        for start in range(0, len(chunks), batch_size):
            batch = chunks[start : start + batch_size]
            err, embeddings = self.embed_texts(batch)
            if err != ErrorCode.SUCCESS or len(embeddings) != len(batch):
                self.log.error(f"index_chunks_for_file: embed failed err={err}, got {len(embeddings)} vectors")
                return err if err != ErrorCode.SUCCESS else ErrorCode.DATA_FORMAT_INVALID
            points = []
            for j, (vec, text) in enumerate(zip(embeddings, batch)):
                i = start + j
                if len(vec) != self._vector_dim:
                    self.log.warning(f"Chunk {i} vector dim {len(vec)} != {self._vector_dim}, skip")
                    continue
                # Qdrant 仅接受 unsigned int 或 UUID，使用确定性整数 ID 避免冲突
                point_id = (kb_id << 40) | (file_id << 20) | i
                points.append({
                    "id": point_id,
                    "vector": vec,
                    "payload": {
                        "rag_id": kb_id,
                        "file_id": file_id,
                        "chunk_index": i,
                        "text": text[:2000],
                        "binding_user_id": binding_user_id,
                    },
                })
            err, n = self._qdrant.insert(points)
            if err != ErrorCode.SUCCESS:
                self.log.error(f"index_chunks_for_file: Qdrant insert failed err={err}")
                return err
            offset_chars += sum(len(c) for c in batch)
            # 每批都更新 MySQL 的 file_embedding_offset，前端轮询 /file/status 时才能看到进度（无论是否启用 Redis）
            self.repo.update_file_record(file_id, {"file_embedding_offset": offset_chars})
            if use_progress and total_chars > 0:
                progress = min(offset_chars / file_char_count, 1.0)
                self.set_rag_file_progress(
                    file_id,
                    embedding_process=1,
                    embedding_progress=progress,
                    file_char_count=file_char_count,
                    file_embedding_offset=offset_chars,
                )
        # 全部写入 Qdrant 后，在 Redis 标记完成，供 status 只查 Redis
        if use_progress and file_char_count > 0:
            self.set_rag_file_progress(
                file_id,
                embedding_process=3,
                embedding_progress=1.0,
                file_char_count=file_char_count,
                file_embedding_offset=offset_chars,
            )
        self.log.info(f"index_chunks_for_file: kb_id={kb_id} file_id={file_id} indexed {len(chunks)} chunks")
        return ErrorCode.SUCCESS

    def embed_and_index_file(
        self,
        kb_id: int,
        file_id: int,
        binding_user_id: int,
        object_name: str,
        bucket: Optional[str] = None,
        chunk_size: int = 500,
    ) -> ErrorCode:
        """
        从 MinIO 读取文件内容，支持 PDF、TXT、Office、HTML；分块后调用 vllm 嵌入并写入 Qdrant。
        若文件类型不支持或读取/解析失败，则视为该文件向量化失败。
        """
        if not object_name or not self._minio_client:
            self.log.warning("embed_and_index_file: missing object_name or MinIO client, treat as failure")
            return ErrorCode.OPERATION_FAILED
        
        # 检查文件扩展名
        file_ext = object_name.lower().split('.')[-1] if '.' in object_name.lower() else ''
        
        if file_ext not in self._supported_file_types:
            self.log.warning(f"embed_and_index_file: unsupported file type '{file_ext}', treat as failure")
            return ErrorCode.NOT_SUPPORTED
        
        b = bucket or self._minio_bucket
        try:
            resp = self._minio_client.get_object(b, object_name)
            content = resp.read()
            resp.close()
        except Exception as e:
            self.log.warning(f"embed_and_index_file: MinIO get_object failed: {e}")
            return ErrorCode.FILE_NOT_FOUND
        
        # 根据文件类型提取文本
        text = self._extract_text_from_file(content, file_ext)
        if not text:
            self.log.warning(f"embed_and_index_file: failed to extract text from {file_ext} file")
            return ErrorCode.INVALID_DATA
        
        chunks = self._chunk_text(text, chunk_size=chunk_size)
        if not chunks:
            self.log.warning("embed_and_index_file: chunk_text returned empty chunks, treat as failure")
            return ErrorCode.INVALID_DATA
        file_char_count = len(text)
        # 写回实际字符数，便于 /file/status 计算进度（PDF 等插入时 char_count 常为 0）
        self.repo.update_file_record(file_id, {"file_char_count": file_char_count})
        self.set_rag_file_progress(
            file_id,
            embedding_process=1,
            embedding_progress=0.0,
            file_char_count=file_char_count,
            file_embedding_offset=0,
        )
        err = self.index_chunks_for_file(
            kb_id, file_id, binding_user_id, chunks,
            file_char_count=file_char_count,
        )
        if err != ErrorCode.SUCCESS:
            return err

        try:
            # 向量化成功后，标记文件已完成嵌入
            self.repo.update_file_record(file_id, {"embedding_process": 3})

            # 重新统计知识库下已完成文件的容量与数量，并写回 rag_tbl
            stats_err, (total_chars, file_cnt) = self.repo.calc_kb_file_stats(kb_id)
            if stats_err == ErrorCode.SUCCESS:
                upd_err, _ = self.repo.update_kb_file_stats(kb_id, total_chars, file_cnt)
                if upd_err != ErrorCode.SUCCESS:
                    self.log.warning(f"update_kb_file_stats failed: {upd_err} for kb_id={kb_id}")
            else:
                self.log.warning(f"calc_kb_file_stats failed: {stats_err} for kb_id={kb_id}")
        except Exception as e:
            self.log.warning(f"update kb file stats exception for kb_id={kb_id}: {e}")

        return ErrorCode.SUCCESS

    def _extract_text_from_file(self, content: bytes, file_ext: str) -> str:
        """
        根据文件类型提取文本内容
        """
        import io
        import re
        
        try:
            if file_ext == 'txt':
                return content.decode("utf-8", errors="replace")
            
            elif file_ext in ['html', 'htm']:
                # HTML文件文本提取
                try:
                    from bs4 import BeautifulSoup
                    soup = BeautifulSoup(content, 'html.parser')
                    # 移除script和style标签
                    for script in soup(["script", "style"]):
                        script.decompose()
                    return soup.get_text(separator=' ', strip=True)
                except ImportError:
                    self.log.warning("BeautifulSoup not available, falling back to regex for HTML")
                    # 简单的HTML标签移除
                    text = re.sub(r'<[^>]+>', ' ', content.decode("utf-8", errors="replace"))
                    return re.sub(r'\s+', ' ', text).strip()
            
            elif file_ext == 'pdf':
                # PDF文件文本提取
                try:
                    import PyPDF2
                    pdf_reader = PyPDF2.PdfReader(io.BytesIO(content))
                    text = ""
                    for page in pdf_reader.pages:
                        text += page.extract_text() + "\n"
                    return text.strip()
                except ImportError:
                    self.log.warning("PyPDF2 not available, cannot extract text from PDF")
                    return ""
            
            elif file_ext in ['doc', 'docx']:
                # Word文档文本提取
                try:
                    if file_ext == 'docx':
                        import docx
                        doc = docx.Document(io.BytesIO(content))
                        text = ""
                        for paragraph in doc.paragraphs:
                            text += paragraph.text + "\n"
                        return text.strip()
                    else:
                        # .doc文件需要python-docx2txt
                        import docx2txt
                        return docx2txt.process(io.BytesIO(content))
                except ImportError:
                    self.log.warning("python-docx or docx2txt not available, cannot extract text from Word documents")
                    return ""
            
            elif file_ext in ['xls', 'xlsx']:
                # Excel文件文本提取
                try:
                    import pandas as pd
                    df = pd.read_excel(io.BytesIO(content))
                    # 将所有单元格内容转换为文本
                    text = ""
                    for _, row in df.iterrows():
                        row_text = " ".join([str(cell) for cell in row if pd.notna(cell)])
                        text += row_text + "\n"
                    return text.strip()
                except ImportError:
                    self.log.warning("pandas not available, cannot extract text from Excel files")
                    return ""
            
            elif file_ext in ['ppt', 'pptx']:
                # PowerPoint文件文本提取
                try:
                    if file_ext == 'pptx':
                        import pptx
                        prs = pptx.Presentation(io.BytesIO(content))
                        text = ""
                        for slide in prs.slides:
                            for shape in slide.shapes:
                                if hasattr(shape, "text"):
                                    text += shape.text + "\n"
                        return text.strip()
                    else:
                        # .ppt文件支持较少，可能需要其他库
                        self.log.warning(".ppt files not fully supported, consider converting to .pptx")
                        return ""
                except ImportError:
                    self.log.warning("python-pptx not available, cannot extract text from PowerPoint files")
                    return ""
            
            else:
                self.log.warning(f"Unsupported file type: {file_ext}")
                return ""
                
        except Exception as e:
            self.log.error(f"Error extracting text from {file_ext} file: {e}")
            return ""

    def check_file_vectorized(self, file_name: str, kb_id: int) -> Tuple[ErrorCode, bool]:
        """
        检查文件是否已经向量化
        先检查MySQL中是否存在文件记录，再检查Qdrant中是否存在向量化数据
        """
        # 1. 检查MySQL中是否存在文件记录
        err, file_record = self.repo.get_file_by_name_and_kb(file_name, kb_id)
        if err != ErrorCode.SUCCESS:
            return err, False
        
        if not file_record:
            # MySQL中不存在文件记录，可以插入
            return ErrorCode.SUCCESS, False
        
        # 2. 检查Qdrant中是否存在向量化数据
        file_id = file_record.get("id")
        if not self._qdrant:
            self.log.warning("check_file_vectorized: Qdrant not available")
            return ErrorCode.SERVICE_UNAVAILABLE, False
        
        err, qdrant_records = self._qdrant.query_by_file_id(
            file_id=file_id,
            collection_name=self._rag_collection,
            limit=1
        )
        
        if err != ErrorCode.SUCCESS:
            return err, False
        
        is_vectorized = len(qdrant_records) > 0
        return ErrorCode.SUCCESS, is_vectorized

    # ============== 知识库管理 ==============

    async def create_knowledge_base(
        self, req: KnowledgeBaseCreateRequest, user_id: int
    ) -> Tuple[ErrorCode, object]:
        """创建知识库 -> rag_tbl，绑定当前用户 binding_user_id"""
        err, exists = await asyncio.to_thread(
            self.repo.exists_by_name, req.name, binding_user_id=user_id
        )
        if err != ErrorCode.SUCCESS:
            self.log.error(f"exists check failed when creating kb: {err}")
            return err, "数据库错误"
        if exists:
            msg = f"知识库名称已存在: {req.name}"
            self.log.warning(msg)
            return ErrorCode.RESOURCE_ALREADY_EXISTS, msg

        data = {
            "rag_name": req.name,
            "type": req.kb_type.value,
            "status": self._map_status_to_db(KnowledgeBaseStatus.ENABLED),
            "file_capacity": 0,
            "file_count": 0,
            "binding_user_id": user_id,
        }
        err, kb_id = await asyncio.to_thread(self.repo.insert_knowledge_base, data)
        if err != ErrorCode.SUCCESS:
            self.log.error(f"insert rag_tbl failed: {err}")
            return err, "创建知识库失败"

        # 读取刚插入的记录，构造 DTO
        err, row = await asyncio.to_thread(self.repo.get_knowledge_base_by_id, kb_id)
        if err != ErrorCode.SUCCESS or not row:
            self.log.error(f"select rag_tbl after insert failed: {err}")
            return err or ErrorCode.DATA_NOT_FOUND, "读取知识库失败"

        kb = self._row_to_kb(row)
        self.log.info(f"Created knowledge base in DB: id={kb.id}, name={kb.name}")
        return ErrorCode.SUCCESS, kb

    async def update_knowledge_base(
        self, req: KnowledgeBaseUpdateRequest, user_id: int
    ) -> Tuple[ErrorCode, object]:
        """更新知识库信息 -> rag_tbl（仅允许操作当前用户绑定的知识库）"""
        err, row = await asyncio.to_thread(
            self.repo.get_knowledge_base_by_id, req.id, binding_user_id=user_id
        )
        if err != ErrorCode.SUCCESS or not row:
            msg = f"知识库不存在或无权操作: {req.id}"
            self.log.warning(msg)
            return ErrorCode.DATA_NOT_FOUND, msg

        if req.name and req.name != row.get("rag_name"):
            err, exists = await asyncio.to_thread(
                self.repo.exists_by_name, req.name, binding_user_id=user_id, exclude_id=req.id
            )
            if err != ErrorCode.SUCCESS:
                self.log.error(f"exists check failed when updating kb: {err}")
                return err, "数据库错误"
            if exists:
                msg = f"知识库名称已存在: {req.name}"
                self.log.warning(msg)
                return ErrorCode.RESOURCE_ALREADY_EXISTS, msg

        update_data: Dict[str, Any] = {}
        if req.name:
            update_data["rag_name"] = req.name
        if req.status is not None:
            update_data["status"] = self._map_status_to_db(req.status)

        if not update_data:
            # 没有任何需要更新的字段，返回当前数据
            kb = self._row_to_kb(row)
            return ErrorCode.SUCCESS, kb

        err, _ = await asyncio.to_thread(
            self.repo.update_knowledge_base, req.id, update_data
        )
        if err != ErrorCode.SUCCESS:
            self.log.error(f"update rag_tbl failed: {err}, data={update_data}")
            return err, "更新知识库失败"

        # 返回更新后的数据
        err, row2 = await asyncio.to_thread(self.repo.get_knowledge_base_by_id, req.id)
        if err != ErrorCode.SUCCESS or not row2:
            self.log.error(f"select rag_tbl after update failed: {err}")
            return err or ErrorCode.DATA_NOT_FOUND, "读取知识库失败"

        kb = self._row_to_kb(row2)
        self.log.info(f"Updated knowledge base in DB: id={kb.id}")
        return ErrorCode.SUCCESS, kb

    async def delete_knowledge_base(
        self, req: KnowledgeBaseIdRequest, user_id: int
    ) -> Tuple[ErrorCode, object]:
        """
        删除知识库（仅允许删除当前用户绑定的知识库），并级联删除：
        - Qdrant 中该知识库下所有文件的向量
        - MinIO 中该知识库下所有文档对象
        - MySQL rag_file_tbl 中该知识库下所有文件记录
        - MySQL rag_tbl 中知识库主记录
        使用事务保证 MySQL 内「先删文件表、再删知识库表」的原子性。
        """
        kb_id = req.id
        err, row = await asyncio.to_thread(
            self.repo.get_knowledge_base_by_id, kb_id, binding_user_id=user_id
        )
        if err != ErrorCode.SUCCESS or not row:
            msg = f"知识库不存在或无权操作: {kb_id}"
            self.log.warning(msg)
            return ErrorCode.DATA_NOT_FOUND, msg

        # 1. 查出该知识库下所有文件（用于删 Qdrant、MinIO）
        err, file_rows = await asyncio.to_thread(
            self.repo.list_files_by_kb, kb_id, limit=50000
        )
        if err != ErrorCode.SUCCESS:
            self.log.error(f"list_files_by_kb failed: {err}, kb_id={kb_id}")
            return err, "查询知识库文件列表失败"
        file_ids = [r["id"] for r in file_rows]
        file_paths = [r.get("file_path") for r in file_rows if r.get("file_path")]

        # 2. 删除 Qdrant 中该知识库下所有 file_id 的向量
        qdrant_deleted = 0
        if file_ids and self._qdrant:
            try:
                filter_condition = rest.Filter(
                    must=[
                        rest.FieldCondition(
                            key="file_id",
                            match=rest.MatchAny(any=file_ids),
                        )
                    ]
                )
                err_del, n_pts = await asyncio.to_thread(
                    self._qdrant.delete,
                    filter=filter_condition,
                    collection_name=self._rag_collection,
                )
                if err_del == ErrorCode.SUCCESS:
                    qdrant_deleted = n_pts
                    self.log.info(f"Qdrant: deleted points for kb_id={kb_id}, file_ids={len(file_ids)}, points={qdrant_deleted}")
                else:
                    self.log.warning(f"Qdrant delete by file_ids failed: {err_del}, kb_id={kb_id}")
            except Exception as e:
                self.log.warning(f"Qdrant delete exception: {e}, kb_id={kb_id}")

        # 3. 删除 MinIO 中该知识库下所有文档对象（放入线程避免阻塞）
        minio_deleted = 0
        if file_paths and self._minio_client:
            def _remove_minio_objects(bucket: str, paths: list) -> int:
                cnt = 0
                for obj_name in paths:
                    try:
                        self._minio_client.remove_object(bucket, obj_name)
                        cnt += 1
                    except Exception:
                        pass
                return cnt
            minio_deleted = await asyncio.to_thread(
                _remove_minio_objects, self._minio_bucket, file_paths
            )
            if minio_deleted > 0:
                self.log.info(f"MinIO: removed {minio_deleted} objects for kb_id={kb_id}")

        # 4. MySQL 事务：先删文件表，再删知识库表（整段事务放入线程，避免阻塞事件循环）
        def _do_delete_tx():
            if self.repo.begin_transaction() != ErrorCode.SUCCESS:
                return ErrorCode.DATABASE_TRANSACTION_ERROR, "开启事务失败", 0
            try:
                err1, n_files = self.repo.delete_files_by_kb(kb_id)
                if err1 != ErrorCode.SUCCESS:
                    self.repo.rollback()
                    return err1, "删除知识库文件记录失败", 0
                err2, n_kb = self.repo.delete_knowledge_base(kb_id)
                if err2 != ErrorCode.SUCCESS:
                    self.repo.rollback()
                    return err2, "删除知识库失败", 0
                if self.repo.commit() != ErrorCode.SUCCESS:
                    self.repo.rollback()
                    return ErrorCode.DATABASE_TRANSACTION_ERROR, "提交事务失败", 0
                return ErrorCode.SUCCESS, None, n_files
            except Exception as e:
                self.repo.rollback()
                return ErrorCode.DATABASE_TRANSACTION_ERROR, f"删除知识库事务异常: {e}", 0

        tx_err, tx_msg, n_files = await asyncio.to_thread(_do_delete_tx)
        if tx_err != ErrorCode.SUCCESS:
            self.log.error(f"delete_kb tx: {tx_msg}")
            return tx_err, tx_msg

        self.log.info(
            f"Deleted knowledge base and cascade: id={kb_id}, "
            f"MySQL files={n_files} kb=1, Qdrant points={qdrant_deleted}, MinIO objects={minio_deleted}"
        )
        return ErrorCode.SUCCESS, None

    async def export_knowledge_base(
        self, req: KnowledgeBaseIdRequest, user_id: int
    ) -> Tuple[ErrorCode, object]:
        """
        导出知识库：返回知识库基础信息 + 关联文件列表（用于前端下载备份）。
        暂不导出向量数据，仅导出 MySQL 中的 rag_tbl / rag_file_tbl 元数据。
        """
        # 校验知识库归属
        err, row = await asyncio.to_thread(
            self.repo.get_knowledge_base_by_id, req.id, binding_user_id=user_id
        )
        if err != ErrorCode.SUCCESS or not row:
            msg = f"知识库不存在或无权导出: {req.id}"
            self.log.warning(msg)
            return ErrorCode.DATA_NOT_FOUND, msg

        kb = self._row_to_kb(row)

        # 读取部分文件记录用于导出（最多 1000 条，后续可根据需要扩展为分页导出）
        err, file_rows = await asyncio.to_thread(
            self.repo.list_files_by_kb, req.id, limit=1000
        )
        if err != ErrorCode.SUCCESS:
            self.log.error(f"list_files_by_kb failed when exporting kb: {err}")
            return err, "查询知识库文件列表失败"

        files: List[Dict[str, Any]] = []
        for r in file_rows:
            upload_time = r.get("upload_time")
            upload_ts = int(upload_time.timestamp() * 1000) if upload_time is not None else 0
            files.append(
                {
                    "id": r.get("id"),
                    "file_name": r.get("file_name", ""),
                    "file_path": r.get("file_path", ""),
                    "extension": r.get("extension", ""),
                    "status": int(r.get("status", 1) or 1),
                    "upload_time": upload_ts,
                    "file_char_count": int(r.get("file_char_count", 0) or 0),
                    "recall_count": int(r.get("recall_count", 0) or 0),
                    "rag_id": int(r.get("rag_id", 0) or 0),
                    "segmentation_type": r.get("segmentation_type", ""),
                }
            )

        export_data = {
            "kb": kb.model_dump(),
            "files": files,
        }
        self.log.info(f"Export knowledge base: id={kb.id}, files={len(files)}")
        return ErrorCode.SUCCESS, export_data

    async def update_file_status(
        self, req: FileUpdateStatusRequest, user_id: int
    ) -> Tuple[ErrorCode, object]:
        """更新单个文件的启用状态，并同步刷新知识库容量与文件数。"""
        # 校验知识库归属
        err, kb_row = await asyncio.to_thread(
            self.repo.get_knowledge_base_by_id, req.kb_id, binding_user_id=user_id
        )
        if err != ErrorCode.SUCCESS or not kb_row:
            msg = f"知识库不存在或无权操作: {req.kb_id}"
            self.log.warning(msg)
            return ErrorCode.DATA_NOT_FOUND, msg

        # 查询文件记录
        err, file_row = await asyncio.to_thread(self.repo.get_file_by_id, req.file_id)
        if err != ErrorCode.SUCCESS or not file_row:
            msg = f"文件不存在: {req.file_id}"
            self.log.warning(msg)
            return ErrorCode.DATA_NOT_FOUND, msg
        if int(file_row.get("rag_id", 0) or 0) != req.kb_id:
            msg = f"文件不属于指定知识库: file_id={req.file_id}, kb_id={req.kb_id}"
            self.log.warning(msg)
            return ErrorCode.DATA_INVALID, msg

        new_status = 1 if req.status == 1 else 0
        old_status = int(file_row.get("status", 1) or 1)
        if new_status == old_status:
            return ErrorCode.SUCCESS, None

        # 更新文件状态
        upd_err, _ = await asyncio.to_thread(
            self.repo.update_file_record, req.file_id, {"status": new_status}
        )
        if upd_err != ErrorCode.SUCCESS:
            self.log.error(f"update_file_status: update_file_record failed err={upd_err}, file_id={req.file_id}")
            return upd_err, "更新文件状态失败"

        # 若文件已完成嵌入，则重新统计知识库的容量与文件数
        embedding_process = int(file_row.get("embedding_process", 0) or 0)
        if embedding_process == 3:
            try:
                stats_err, (total_chars, file_cnt) = await asyncio.to_thread(
                    self.repo.calc_kb_file_stats, req.kb_id
                )
                if stats_err == ErrorCode.SUCCESS:
                    upd_kb_err, _ = await asyncio.to_thread(
                        self.repo.update_kb_file_stats, req.kb_id, total_chars, file_cnt
                    )
                    if upd_kb_err != ErrorCode.SUCCESS:
                        self.log.warning(
                            f"update_file_status: update_kb_file_stats failed: {upd_kb_err} for kb_id={req.kb_id}"
                        )
                else:
                    self.log.warning(
                        f"update_file_status: calc_kb_file_stats failed: {stats_err} for kb_id={req.kb_id}"
                    )
            except Exception as e:
                self.log.warning(f"update_file_status: refresh kb stats exception for kb_id={req.kb_id}: {e}")

        return ErrorCode.SUCCESS, None

    async def delete_file(
        self, req: FileIdWithKbRequest, user_id: int
    ) -> Tuple[ErrorCode, object]:
        """删除单个文件：清理 Redis/Qdrant/MinIO/MySQL，并刷新知识库容量与文件数。"""
        # 校验知识库归属
        err, kb_row = await asyncio.to_thread(
            self.repo.get_knowledge_base_by_id, req.kb_id, binding_user_id=user_id
        )
        if err != ErrorCode.SUCCESS or not kb_row:
            msg = f"知识库不存在或无权操作: {req.kb_id}"
            self.log.warning(msg)
            return ErrorCode.DATA_NOT_FOUND, msg

        # 查询文件记录
        err, file_row = await asyncio.to_thread(self.repo.get_file_by_id, req.file_id)
        if err != ErrorCode.SUCCESS or not file_row:
            msg = f"文件不存在: {req.file_id}"
            self.log.warning(msg)
            return ErrorCode.DATA_NOT_FOUND, msg
        if int(file_row.get("rag_id", 0) or 0) != req.kb_id:
            msg = f"文件不属于指定知识库: file_id={req.file_id}, kb_id={req.kb_id}"
            self.log.warning(msg)
            return ErrorCode.DATA_INVALID, msg

        object_name = file_row.get("file_path") or None
        # 清理单个文件相关资源（内部会删除 rag_file_tbl 记录）
        await asyncio.to_thread(
            self.cleanup_file_resources, req.kb_id, req.file_id, object_name, None
        )

        # 删除后重新统计知识库的容量与文件数
        try:
            stats_err, (total_chars, file_cnt) = await asyncio.to_thread(
                self.repo.calc_kb_file_stats, req.kb_id
            )
            if stats_err == ErrorCode.SUCCESS:
                upd_kb_err, _ = await asyncio.to_thread(
                    self.repo.update_kb_file_stats, req.kb_id, total_chars, file_cnt
                )
                if upd_kb_err != ErrorCode.SUCCESS:
                    self.log.warning(
                        f"delete_file: update_kb_file_stats failed: {upd_kb_err} for kb_id={req.kb_id}"
                    )
            else:
                self.log.warning(
                    f"delete_file: calc_kb_file_stats failed: {stats_err} for kb_id={req.kb_id}"
                )
        except Exception as e:
            self.log.warning(f"delete_file: refresh kb stats exception for kb_id={req.kb_id}: {e}")

        return ErrorCode.SUCCESS, None

    async def get_file_download_url(
        self, req: FileIdWithKbRequest, user_id: int
    ) -> Tuple[ErrorCode, object]:
        """获取文件下载链接（MinIO 预签名 URL）。"""
        if not self._minio_client:
            self.log.warning("get_file_download_url: MinIO client not configured")
            return ErrorCode.SERVICE_UNAVAILABLE, "文件存储服务未配置"

        # 校验知识库归属
        err, kb_row = await asyncio.to_thread(
            self.repo.get_knowledge_base_by_id, req.kb_id, binding_user_id=user_id
        )
        if err != ErrorCode.SUCCESS or not kb_row:
            msg = f"知识库不存在或无权操作: {req.kb_id}"
            self.log.warning(msg)
            return ErrorCode.DATA_NOT_FOUND, msg

        # 查询文件记录
        err, file_row = await asyncio.to_thread(self.repo.get_file_by_id, req.file_id)
        if err != ErrorCode.SUCCESS or not file_row:
            msg = f"文件不存在: {req.file_id}"
            self.log.warning(msg)
            return ErrorCode.DATA_NOT_FOUND, msg
        if int(file_row.get("rag_id", 0) or 0) != req.kb_id:
            msg = f"文件不属于指定知识库: file_id={req.file_id}, kb_id={req.kb_id}"
            self.log.warning(msg)
            return ErrorCode.DATA_INVALID, msg

        object_name = file_row.get("file_path")
        if not object_name:
            self.log.warning(f"get_file_download_url: file_path empty for file_id={req.file_id}")
            return ErrorCode.DATA_INVALID, "文件存储路径不存在"

        try:
            expires = timedelta(hours=1)
            file_name = file_row.get("file_name") or object_name.split("/")[-1]
            encoded_name = quote(file_name)
            response_headers = {
                "response-content-disposition": f"attachment; filename*=UTF-8''{encoded_name}"
            }
            url = await asyncio.to_thread(
                self._minio_client.presigned_get_object,
                self._minio_bucket,
                object_name,
                expires,
                response_headers,
            )
        except Exception as e:
            self.log.error(f"get_file_download_url: presigned_get_object failed for file_id={req.file_id}: {e}")
            return ErrorCode.EXTERNAL_SERVICE_ERROR, "生成下载地址失败"

        data = {
            "url": url,
            "file_name": file_row.get("file_name", ""),
        }
        return ErrorCode.SUCCESS, data

    async def get_knowledge_base(
        self, req: KnowledgeBaseIdRequest, user_id: int
    ) -> Tuple[ErrorCode, object]:
        """查询单个知识库详情（仅当前用户绑定的知识库）"""
        err, row = await asyncio.to_thread(
            self.repo.get_knowledge_base_by_id, req.id, binding_user_id=user_id
        )
        if err != ErrorCode.SUCCESS or not row:
            msg = f"知识库不存在或无权查看: {req.id}"
            self.log.warning(msg)
            return ErrorCode.DATA_NOT_FOUND, msg

        kb = self._row_to_kb(row)
        return ErrorCode.SUCCESS, kb

    async def list_knowledge_items(
        self, req: KnowledgeItemListRequest, user_id: int
    ) -> Tuple[ErrorCode, object]:
        err, kb_row = await asyncio.to_thread(
            self.repo.get_knowledge_base_by_id, req.kb_id, binding_user_id=user_id
        )
        if err != ErrorCode.SUCCESS or not kb_row:
            msg = f"知识库不存在或无权查看: {req.kb_id}"
            self.log.warning(msg)
            return ErrorCode.DATA_NOT_FOUND, msg

        err, rows = await asyncio.to_thread(
            self.repo.list_knowledge_items_by_kb,
            req.kb_id,
            req.min_recall_count,
            req.max_recall_count,
            req.recent_days,
            req.sort_by,
            req.sort_order or "desc",
        )
        if err != ErrorCode.SUCCESS:
            self.log.error(f"list_knowledge_items_by_kb failed: {err} for kb_id={req.kb_id}")
            return err, "查询知识信息列表失败"

        items: List[KnowledgeItemInfo] = []
        for r in rows:
            upload_time = r.get("upload_time")
            ts = (
                upload_time.strftime("%Y-%m-%d %H:%M:%S")
                if upload_time is not None
                else None
            )
            item = KnowledgeItemInfo(
                id=int(r.get("id", 0) or 0),
                file_name=r.get("file_name", "") or "",
                recall_count=int(r.get("recall_count", 0) or 0),
                last_access_time=None,
                avg_score=None,
                instruction_score=None,
                relevance_score=None,
                is_noise=False,
                is_redundant=False,
                created_at=ts,
                updated_at=ts,
            )
            items.append(item)

        return ErrorCode.SUCCESS, {"items": [i.model_dump() for i in items]}

    async def list_knowledge_bases(
        self, req: KnowledgeBaseListRequest, user_id: int
    ) -> Tuple[ErrorCode, object]:
        """分页查询当前用户知识库列表 -> rag_tbl"""
        err, total = await asyncio.to_thread(
            self.repo.count_knowledge_bases, binding_user_id=user_id, keyword=req.keyword
        )
        if err != ErrorCode.SUCCESS:
            self.log.error(f"count rag_tbl failed: {err}")
            return err, "查询知识库数量失败"

        offset = (req.page_no - 1) * req.page_size
        err, rows = await asyncio.to_thread(
            self.repo.list_knowledge_bases,
            binding_user_id=user_id,
            keyword=req.keyword,
            limit=req.page_size,
            offset=offset,
        )
        if err != ErrorCode.SUCCESS:
            self.log.error(f"select rag_tbl failed: {err}")
            return err, "查询知识库列表失败"

        items: List[KnowledgeBaseInfo] = [self._row_to_kb(r) for r in rows]
        page = KnowledgeBasePage(
            items=items,
            total=total,
            page_no=req.page_no,
            page_size=req.page_size,
        )
        return ErrorCode.SUCCESS, page

    # ============== RAG 问答（使用 vllm Embedding + Qdrant） ==============

    async def rag_query(
        self, req: RagQueryRequest, user_id: int
    ) -> Tuple[ErrorCode, object]:
        """RAG 问答接口：对 query 做向量化，在 Qdrant 中按知识库与用户过滤做相似检索。"""
        # 1. 校验知识库归属
        err, kb_row = await asyncio.to_thread(
            self.repo.get_knowledge_base_by_id,
            req.kb_id, binding_user_id=user_id
        )
        if err != ErrorCode.SUCCESS or not kb_row:
            msg = f"知识库不存在: {req.kb_id}"
            self.log.warning(msg)
            return ErrorCode.DATA_NOT_FOUND, msg

        kb = self._row_to_kb(kb_row)

        # 2. 检查向量服务是否可用
        if not self._embedding_client or not self._embedding_client.is_available() or not self._qdrant:
            msg = "RAG 向量服务未启用或不可用"
            self.log.warning(f"rag_query: {msg}")
            return ErrorCode.SERVICE_UNAVAILABLE, msg

        # 3. 对查询语句做向量化（embed 为同步 I/O，放入线程）
        err, embeddings = await asyncio.to_thread(self.embed_texts, [req.query])
        if err != ErrorCode.SUCCESS or not embeddings or not embeddings[0]:
            self.log.error(f"rag_query: embed_texts failed err={err}")
            return err if err != ErrorCode.SUCCESS else ErrorCode.DATA_INVALID, "问题向量化失败"
        query_vec = embeddings[0]

        # 4. 在 Qdrant 中按 rag_id / binding_user_id 过滤做相似度检索
        qdrant_filter = {
            "must": [
                {"key": "rag_id", "match": {"value": kb.id}},
                {"key": "binding_user_id", "match": {"value": user_id}},
            ]
        }
        err, results = await asyncio.to_thread(
            self._qdrant.query_by_vector_with_filter,
            query_vector=query_vec,
            collection_name=self._rag_collection,
            qdrant_filter=qdrant_filter,
            limit=req.top_k,
            score_threshold=0.5,
            with_payload=True,
        )
        if err != ErrorCode.SUCCESS:
            self.log.error(f"rag_query: Qdrant query failed err={err}")
            return err, "知识检索失败"

        # 5. 构造来源文档（使用存储的分段文本片段）
        source_documents: List[str] = []
        for item in results:
            payload = item.get("payload") or {}
            text = payload.get("text", "")
            score = item.get("score", 0.0)
            snippet = text[:200].replace("\n", " ")
            source_documents.append(f"{snippet} ... (score={score:.3f})" if snippet else f"(score={score:.3f})")

        if not source_documents:
            answer = f"在知识库「{kb.name}」中未找到与问题「{req.query}」高度相关的内容。"
        else:
            # 简单拼接检索到的片段，后续可以接入大模型生成自然语言回答
            joined = "\n".join(f"- {doc}" for doc in source_documents)
            answer = (
                f"这是根据知识库「{kb.name}」中检索到的相关内容给出的回答示例：\n\n"
                f"{joined}\n\n"
                f"（后续可以在此基础上接入大模型生成更自然的回答）"
            )

        result = RagQueryAnswer(
            answer=answer,
            kb_id=kb.id,
            query=req.query,
            top_k=req.top_k,
            source_documents=source_documents,
        )
        return ErrorCode.SUCCESS, result

    async def all_kb_name_list(
        self, req: KnowledgeBaseListRequest, user_id: int
    ) -> Tuple[ErrorCode, object]:
        """查询当前用户下所有知识库名称列表（用于下拉等），返回 id 和 name 列表"""
        err, rows = await asyncio.to_thread(
            self.repo.list_knowledge_bases,
            binding_user_id=user_id,
            keyword=req.keyword,
            limit=1000,
            offset=0,
        )
        if err != ErrorCode.SUCCESS:
            return err, "查询知识库列表失败"
        items = [{"id": r.get("id"), "name": r.get("rag_name", "")} for r in rows if r.get("rag_name")]
        return ErrorCode.SUCCESS, items

    def get_file_vectorization_status(
        self, req: FileVectorizationStatusRequest, user_id: int
    ) -> Tuple[ErrorCode, FileVectorizationStatusResponse]:
        """
        查询文件向量化状态。支持按 file_id 或 file_name 查询。
        - 校验知识库归属
        - 检查MySQL中的文件记录
        - 检查Qdrant中的向量化数据
        """
        if req.file_id is None and not (req.file_name and req.file_name.strip()):
            return ErrorCode.INVALID_PARAMETER, FileVectorizationStatusResponse(
                file_name=req.file_name or "",
                kb_id=req.kb_id,
                is_vectorized=False,
                error_message="请提供 file_id 或 file_name"
            )

        # 1. 校验知识库归属
        err, kb_row = self.repo.get_knowledge_base_by_id(req.kb_id, binding_user_id=user_id)
        if err != ErrorCode.SUCCESS:
            msg = f"数据库查询失败: {err}"
            self.log.error(msg)
            return err, FileVectorizationStatusResponse(
                file_name=req.file_name or "",
                kb_id=req.kb_id,
                is_vectorized=False,
                error_message=msg
            )
        if not kb_row:
            msg = f"知识库不存在或无权操作: {req.kb_id}"
            self.log.warning(msg)
            return ErrorCode.DATA_NOT_FOUND, FileVectorizationStatusResponse(
                file_name=req.file_name or "",
                kb_id=req.kb_id,
                is_vectorized=False,
                error_message=msg
            )

        # 2. 获取文件记录：优先按 file_id，否则按 file_name + kb_id
        file_record = None
        if req.file_id is not None:
            err, file_record = self.repo.get_file_by_id(req.file_id)
            if err != ErrorCode.SUCCESS:
                self.log.error(f"get_file_vectorization_status: get_file_by_id failed err={err}")
                return err, FileVectorizationStatusResponse(
                    file_name=req.file_name or "",
                    kb_id=req.kb_id,
                    is_vectorized=False,
                    error_message="数据库查询失败"
                )
            if file_record and file_record.get("rag_id") != req.kb_id:
                return ErrorCode.DATA_NOT_FOUND, FileVectorizationStatusResponse(
                    file_name=file_record.get("file_name", ""),
                    kb_id=req.kb_id,
                    is_vectorized=False,
                    error_message="文件不属于该知识库"
                )
        else:
            err, file_record = self.repo.get_file_by_name_and_kb(req.file_name, req.kb_id)
            if err != ErrorCode.SUCCESS:
                self.log.error(f"get_file_vectorization_status: get_file_by_name_and_kb failed err={err}")
                return err, FileVectorizationStatusResponse(
                    file_name=req.file_name or "",
                    kb_id=req.kb_id,
                    is_vectorized=False,
                    error_message="数据库查询失败"
                )

        file_name_for_resp = (file_record.get("file_name") if file_record else None) or req.file_name or ""

        if not file_record:
            # MySQL中不存在文件记录
            return ErrorCode.SUCCESS, FileVectorizationStatusResponse(
                file_name=file_name_for_resp,
                kb_id=req.kb_id,
                is_vectorized=False,
                file_id=None,
                embedding_status=0,
                embedding_progress=0.0
            )

        # 3. 进度只查 Redis（每次写入 Qdrant 后已更新 Redis；完成时也在 Redis 标记）
        file_id = file_record.get("id")
        redis_progress = self.get_rag_file_progress(file_id)

        def _safe_float(v, default: float = 0.0) -> float:
            try:
                f = float(v) if v is not None else default
                return default if (f != f or f < 0 or f > 1) else min(f, 1.0)  # 过滤 NaN/Inf
            except (TypeError, ValueError):
                return default

        if redis_progress is not None:
            # 以 Redis 为准：进度、状态、是否已完成均来自 Redis
            embedding_process = redis_progress.get("embedding_process", 0)
            embedding_progress = _safe_float(redis_progress.get("embedding_progress"), 0.0)
            file_char_count = redis_progress.get("file_char_count") or 0
            file_embedding_offset = redis_progress.get("file_embedding_offset")
            if embedding_process != 3 and file_char_count and file_embedding_offset is not None:
                try:
                    embedding_progress = min(float(file_embedding_offset) / max(1, int(file_char_count)), 1.0)
                except (TypeError, ValueError, ZeroDivisionError):
                    pass
            error_message = redis_progress.get("error_message")
            is_vectorized = embedding_process == 3
            if is_vectorized:
                embedding_progress = 1.0
                self.clear_rag_file_progress(file_id)
        else:
            # 无 Redis 时用 DB 兜底（未启用 Redis 或尚未写入）
            embedding_process = file_record.get("embedding_process", 0)
            file_char_count = file_record.get("file_char_count", 0)
            file_embedding_offset = file_record.get("file_embedding_offset", 0)
            error_message = None
            if file_char_count and file_embedding_offset:
                try:
                    embedding_progress = min(float(file_embedding_offset) / max(1, int(file_char_count)), 1.0)
                except (TypeError, ValueError, ZeroDivisionError):
                    embedding_progress = 0.0
            else:
                embedding_progress = 0.0
            is_vectorized = embedding_process == 3
            if is_vectorized:
                embedding_progress = 1.0

        if embedding_process == 1:
            embedding_status = 2  # 正在向量化知识
        elif embedding_process == 2:
            embedding_status = 1  # 正在上传文件
        elif embedding_process == 4:
            embedding_status = 4  # 失败
        elif embedding_process == 3:
            embedding_status = 3  # 已完成
        else:
            embedding_status = 0  # 未开始

        return ErrorCode.SUCCESS, FileVectorizationStatusResponse(
            file_name=file_name_for_resp,
            kb_id=req.kb_id,
            is_vectorized=is_vectorized,
            file_id=file_id,
            embedding_status=embedding_status,
            embedding_progress=embedding_progress,
            error_message=error_message
        )

