import asyncio

from fastapi import FastAPI, Depends

from infrastructure.common.error.errcode import ErrorCode
from infrastructure.common.logging.logging import logger
from infrastructure.config.sys_config import SysConfig
from interfaces.controller.base_controller import BaseController
from interfaces.deps.user_context import UserContext, get_validated_user_context
from interfaces.dto.role_dto import (
    ApplicationRoleListApiRequest,
    ApplicationRoleSaveApiRequest,
    ApplicationRoleIdApiRequest,
    ApplicationRoleToggleStatusApiRequest,
)
from interfaces.dto.response_dto import ApiResponse, ok, fail
from domain.service.application_role_service import ApplicationRoleService


@logger()
class ApplicationRoleController(BaseController):
    def __init__(self, config: SysConfig, web_app: FastAPI, mysql_client=None):
        self.config = config
        self.app = web_app
        self.role_service = ApplicationRoleService(config, mysql_client)
        self._register_routes()

    def _register_routes(self):
        @self.app.post("/v1/agent/role/list", response_model=ApiResponse)
        async def list_roles(
            request: ApplicationRoleListApiRequest,
            user_ctx: UserContext = Depends(get_validated_user_context),
        ):
            try:
                _ = user_ctx
                err, result = await asyncio.to_thread(
                    self.role_service.list_roles, request.data
                )
                if err == ErrorCode.SUCCESS:
                    data = (
                        result.model_dump()
                        if hasattr(result, "model_dump")
                        else result
                    )
                    return ok(data)
                return fail(err, result)
            except Exception as e:
                return fail(ErrorCode.SYSTEM_ERROR, str(e))

        @self.app.post("/v1/agent/role/create", response_model=ApiResponse)
        async def create_role(
            request: ApplicationRoleSaveApiRequest,
            user_ctx: UserContext = Depends(get_validated_user_context),
        ):
            try:
                _ = user_ctx
                err, result = await asyncio.to_thread(
                    self.role_service.create_role, request.data
                )
                if err == ErrorCode.SUCCESS:
                    data = (
                        result.model_dump()
                        if hasattr(result, "model_dump")
                        else result
                    )
                    return ok(data)
                return fail(err, result)
            except Exception as e:
                return fail(ErrorCode.SYSTEM_ERROR, str(e))

        @self.app.post("/v1/agent/role/get", response_model=ApiResponse)
        async def get_role(
            request: ApplicationRoleIdApiRequest,
            user_ctx: UserContext = Depends(get_validated_user_context),
        ):
            try:
                _ = user_ctx
                err, result = await asyncio.to_thread(
                    self.role_service.get_role, request.data
                )
                if err == ErrorCode.SUCCESS:
                    data = (
                        result.model_dump()
                        if hasattr(result, "model_dump")
                        else result
                    )
                    return ok(data)
                return fail(err, result)
            except Exception as e:
                return fail(ErrorCode.SYSTEM_ERROR, str(e))

        @self.app.post("/v1/agent/role/update", response_model=ApiResponse)
        async def update_role(
            request: ApplicationRoleSaveApiRequest,
            user_ctx: UserContext = Depends(get_validated_user_context),
        ):
            try:
                _ = user_ctx
                err, result = await asyncio.to_thread(
                    self.role_service.update_role, request.data
                )
                if err == ErrorCode.SUCCESS:
                    data = (
                        result.model_dump()
                        if hasattr(result, "model_dump")
                        else result
                    )
                    return ok(data)
                return fail(err, result)
            except Exception as e:
                return fail(ErrorCode.SYSTEM_ERROR, str(e))

        @self.app.post("/v1/agent/role/delete", response_model=ApiResponse)
        async def delete_role(
            request: ApplicationRoleIdApiRequest,
            user_ctx: UserContext = Depends(get_validated_user_context),
        ):
            try:
                _ = user_ctx
                err, result = await asyncio.to_thread(
                    self.role_service.delete_role, request.data
                )
                if err == ErrorCode.SUCCESS:
                    return ok()
                return fail(err, result)
            except Exception as e:
                return fail(ErrorCode.SYSTEM_ERROR, str(e))

        @self.app.post("/v1/agent/role/toggle_status", response_model=ApiResponse)
        async def toggle_status(
            request: ApplicationRoleToggleStatusApiRequest,
            user_ctx: UserContext = Depends(get_validated_user_context),
        ):
            try:
                _ = user_ctx
                err, result = await asyncio.to_thread(
                    self.role_service.toggle_status, request.data
                )
                if err == ErrorCode.SUCCESS:
                    data = (
                        result.model_dump()
                        if hasattr(result, "model_dump")
                        else result
                    )
                    return ok(data)
                return fail(err, result)
            except Exception as e:
                return fail(ErrorCode.SYSTEM_ERROR, str(e))

