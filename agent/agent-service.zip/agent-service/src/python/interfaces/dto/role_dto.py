from typing import List, Optional

from pydantic import BaseModel, Field
from pydantic import ConfigDict

from interfaces.dto.rag_dto import StrEnum


class ApplicationRoleStatus(StrEnum):
    ENABLED = "enabled"
    DISABLED = "disabled"


class ApplicationRoleInfo(BaseModel):
    id: int = Field(...)
    name: str = Field(...)
    createdAt: str = Field(default="")
    enableTime: str = Field(default="")
    enablePeriod: str = Field(default="")
    enabled: bool = Field(default=True)
    promptId: Optional[int] = Field(default=None)
    customPrompt: Optional[str] = Field(default=None)


class ApplicationRolePage(BaseModel):
    items: List[ApplicationRoleInfo] = Field(default_factory=list)
    total: int = Field(default=0)
    page: int = Field(default=1)
    size: int = Field(default=10)


class ApplicationRoleListRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    page: int = Field(default=1, ge=1, alias="page")
    size: int = Field(default=10, ge=1, le=100, alias="size")
    keyword: Optional[str] = Field(default=None)
    status: Optional[ApplicationRoleStatus] = Field(default=None)


class ApplicationRoleSaveRequest(BaseModel):
    id: Optional[int] = Field(default=None)
    name: str = Field(...)
    enableTime: str = Field(default="")
    enablePeriod: str = Field(default="")
    promptId: Optional[int] = Field(default=None)
    customPrompt: Optional[str] = Field(default=None)
    enabled: Optional[bool] = Field(default=True)


class ApplicationRoleIdRequest(BaseModel):
    id: int = Field(...)


class ApplicationRoleToggleStatusRequest(BaseModel):
    id: int = Field(...)
    enabled: bool = Field(...)


class ApplicationRoleListApiRequest(BaseModel):
    tag: Optional[str] = Field(default=None)
    timestamp: int = Field(...)
    data: ApplicationRoleListRequest = Field(...)


class ApplicationRoleSaveApiRequest(BaseModel):
    tag: Optional[str] = Field(default=None)
    timestamp: int = Field(...)
    data: ApplicationRoleSaveRequest = Field(...)


class ApplicationRoleIdApiRequest(BaseModel):
    tag: Optional[str] = Field(default=None)
    timestamp: int = Field(...)
    data: ApplicationRoleIdRequest = Field(...)


class ApplicationRoleToggleStatusApiRequest(BaseModel):
    tag: Optional[str] = Field(default=None)
    timestamp: int = Field(...)
    data: ApplicationRoleToggleStatusRequest = Field(...)

