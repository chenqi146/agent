
import asyncio
import os
import sys

# Add project root to path
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(os.path.dirname(os.path.dirname(current_dir)))
sys.path.append(os.path.join(project_root, 'src', 'python'))

from domain.service.agent_service import AgentService
from infrastructure.common.error.errcode import ErrorCode

async def main():
    try:
        print("Initializing AgentService...")
        service = AgentService()
        
        print("Calling get_history with user_id=1...")
        # Assuming user_id 1 exists or at least query works
        err, result = await service.get_history(1)
        
        if err == ErrorCode.SUCCESS:
            print("Success!")
            print(f"Result: {result}")
        else:
            print(f"Failed with error code: {err}")
            
    except Exception as e:
        print(f"Exception occurred: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(main())
