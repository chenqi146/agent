
import asyncio
import os
import sys
import uuid
from datetime import datetime

# Add project root to path
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(os.path.dirname(os.path.dirname(current_dir)))
sys.path.append(os.path.join(project_root, 'src', 'python'))

from domain.service.agent_service import AgentService
from infrastructure.common.error.errcode import ErrorCode

async def main():
    try:
        print("Initializing AgentService...")
        service = AgentService()
        
        user_id = 1
        conversation_id = str(uuid.uuid4())
        
        print(f"Creating test conversation {conversation_id} for user {user_id}...")
        # Create a conversation manually using repository
        data = {
            "conversation_id": conversation_id,
            "user_id": user_id,
            "title": "Test Conversation",
            "model_name": "test-model",
            "is_pinned": 0,
            "message_count": 1,
            "token_count": 100,
            "last_message_time": datetime.now(),
            "is_deleted": 0,
            "created_at": datetime.now(),
            "updated_at": datetime.now()
        }
        err, _ = service.repository.create_conversation(data)
        if err != ErrorCode.SUCCESS:
            print(f"Failed to create conversation: {err}")
            return

        print("Calling get_history...")
        err, result = await service.get_history(user_id)
        
        if err == ErrorCode.SUCCESS:
            print("Success!")
            print(f"Result: {result}")
        else:
            print(f"Failed with error code: {err}")
            
        # Clean up
        print("Cleaning up...")
        service.repository.delete_conversation(conversation_id)
            
    except Exception as e:
        print(f"Exception occurred: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(main())
