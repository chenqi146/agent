from typing import Any, Dict, List, Tuple, Optional

from infrastructure.common.logging.logging import logger
from infrastructure.common.error.errcode import ErrorCode
from infrastructure.config.sys_config import SysConfig
from infrastructure.persistences.mysql_persistence import MysqlPersistence


@logger()
class RagRepository:
    """
    RAG 知识库持久化仓储
    - 负责对 rag_tbl / rag_file_tbl 的所有 MySQL 访问
    - 不包含任何业务规则，只做数据读写
    """

    def __init__(self, config: SysConfig, mysql_client=None):
        if mysql_client:
            self.mysql = mysql_client
        else:
            # 兼容性：如果没有传入mysql_client，则从配置创建
            system_cfg = config.get_system_config() or {}
            mysql_cfg = system_cfg.get("persistence", {}).get("mysql", {}) or {}
            self.mysql = MysqlPersistence(
                host=mysql_cfg.get("host", "127.0.0.1"),
                port=mysql_cfg.get("port", 3306),
                username=mysql_cfg.get("username", "root"),
                password=mysql_cfg.get("password", ""),
                database=mysql_cfg.get("database", "pg-platform-db"),
                charset=mysql_cfg.get("charset", "utf8mb4"),
            )
        self.log.info(
            f"RagRepository initialized with MySQL[{self.mysql.host}:{self.mysql.port}/{self.mysql.database}]"
        )

    # ---------- rag_tbl ----------

    def exists_by_name(
        self,
        name: str,
        binding_user_id: int,
        exclude_id: Optional[int] = None,
    ) -> Tuple[ErrorCode, bool]:
        """检查 rag_tbl 中 rag_name 是否存在（同用户下），支持排除某个 id（更新时使用）"""
        if exclude_id is None:
            return self.mysql.exists(
                "rag_tbl", "rag_name = %s AND binding_user_id = %s", params=(name, binding_user_id)
            )
        return self.mysql.exists(
            "rag_tbl",
            "rag_name = %s AND binding_user_id = %s AND id <> %s",
            params=(name, binding_user_id, exclude_id),
        )

    def insert_knowledge_base(self, data: Dict[str, Any]) -> Tuple[ErrorCode, int]:
        """插入一条知识库记录，返回 (错误码, 新ID)"""
        return self.mysql.insert("rag_tbl", data)

    def get_knowledge_base_by_id(
        self, kb_id: int, binding_user_id: Optional[int] = None
    ) -> Tuple[ErrorCode, Optional[Dict[str, Any]]]:
        """根据 ID 查询单个知识库；若传 binding_user_id 则校验归属"""
        if binding_user_id is not None:
            return self.mysql.select_one(
                "rag_tbl",
                condition="id = %s AND binding_user_id = %s",
                params=(kb_id, binding_user_id),
            )
        return self.mysql.select_one("rag_tbl", condition="id = %s", params=(kb_id,))

    def update_knowledge_base(self, kb_id: int, data: Dict[str, Any]) -> Tuple[ErrorCode, int]:
        """更新知识库"""
        return self.mysql.update(
            "rag_tbl", data=data, condition="id = %s", params=(kb_id,)
        )

    def calc_kb_file_stats(self, kb_id: int) -> Tuple[ErrorCode, Tuple[int, int]]:
        """
        计算指定知识库下已完成嵌入文件的总字符数和文件数
        返回 (错误码, (total_chars, file_count))
        """
        err, rows = self.mysql.select(
            "rag_file_tbl",
            columns=[
                "COALESCE(SUM(file_char_count), 0) AS total_chars",
                "COUNT(*) AS file_count",
            ],
            condition="rag_id = %s AND status = 1 AND embedding_process = 3",
            params=(kb_id,),
        )
        if err != ErrorCode.SUCCESS:
            return err, (0, 0)
        row = rows[0] if rows else {}
        total_chars = int(row.get("total_chars", 0) or 0)
        file_count = int(row.get("file_count", 0) or 0)
        return ErrorCode.SUCCESS, (total_chars, file_count)

    def update_kb_file_stats(
        self, kb_id: int, file_capacity: int, file_count: int
    ) -> Tuple[ErrorCode, int]:
        """更新知识库的容量和文件数量"""
        data = {
            "file_capacity": int(file_capacity),
            "file_count": int(file_count),
        }
        return self.update_knowledge_base(kb_id, data)

    def delete_knowledge_base(self, kb_id: int) -> Tuple[ErrorCode, int]:
        """删除知识库主表记录（调用方需先删 rag_file_tbl，并在事务内调用）"""
        return self.mysql.delete(
            "rag_tbl", condition="id = %s", params=(kb_id,)
        )

    def delete_files_by_kb(self, kb_id: int) -> Tuple[ErrorCode, int]:
        """删除指定知识库下所有文件记录（rag_file_tbl），应在事务内与 delete_knowledge_base 一起使用"""
        return self.mysql.delete(
            "rag_file_tbl", condition="rag_id = %s", params=(kb_id,)
        )

    def delete_file_by_id(self, file_id: int) -> Tuple[ErrorCode, int]:
        """按文件ID删除单个文件记录"""
        return self.mysql.delete(
            "rag_file_tbl", condition="id = %s", params=(file_id,)
        )

    def delete_file_by_id(self, file_id: int) -> Tuple[ErrorCode, int]:
        """按文件ID删除单个文件记录"""
        return self.mysql.delete(
            "rag_file_tbl", condition="id = %s", params=(file_id,)
        )

    def begin_transaction(self) -> ErrorCode:
        """开启 MySQL 事务（与 commit/rollback 配合使用）"""
        return self.mysql.begin_transaction()

    def commit(self) -> ErrorCode:
        """提交 MySQL 事务"""
        return self.mysql.commit()

    def rollback(self) -> ErrorCode:
        """回滚 MySQL 事务"""
        return self.mysql.rollback()

    def count_knowledge_bases(
        self,
        binding_user_id: int,
        keyword: Optional[str] = None,
    ) -> Tuple[ErrorCode, int]:
        """统计当前用户知识库数量，支持名称关键字模糊搜索"""
        condition = "binding_user_id = %s"
        params: Tuple[Any, ...] = (binding_user_id,)
        if keyword:
            condition += " AND rag_name LIKE %s"
            params = (binding_user_id, f"%{keyword}%")
        return self.mysql.count("rag_tbl", condition=condition, params=params)

    def list_knowledge_bases(
        self,
        binding_user_id: int,
        keyword: Optional[str],
        limit: int,
        offset: int,
    ) -> Tuple[ErrorCode, List[Dict[str, Any]]]:
        """
        分页查询当前用户知识库列表
        使用 rag_tbl 与 rag_file_tbl 关联统计文件容量与数量：
        - file_capacity: 该知识库下已完成嵌入文件的总字符数
        - file_count:   该知识库下已完成嵌入文件的数量
        """
        sql = """
SELECT
    k.*,
    COALESCE(fs.total_chars, 0) AS file_capacity,
    COALESCE(fs.file_count, 0) AS file_count
FROM rag_tbl AS k
LEFT JOIN (
    SELECT
        rag_id,
        COALESCE(SUM(file_char_count), 0) AS total_chars,
        COUNT(*) AS file_count
    FROM rag_file_tbl
    WHERE status = 1 AND embedding_process = 3
    GROUP BY rag_id
) AS fs ON fs.rag_id = k.id
WHERE k.binding_user_id = %s
"""
        params: list[Any] = [binding_user_id]
        if keyword:
            sql += " AND k.rag_name LIKE %s"
            params.append(f"%{keyword}%")
        sql += " ORDER BY k.create_time DESC LIMIT %s OFFSET %s"
        params.extend([limit, offset])
        return self.mysql.execute_sql(sql, tuple(params))

    # ---------- rag_file_tbl ----------

    def list_files_by_kb(
        self, kb_id: int, limit: int
    ) -> Tuple[ErrorCode, List[Dict[str, Any]]]:
        """按知识库 ID 查询部分文件记录，用于构造 RAG 来源信息"""
        return self.mysql.select(
            "rag_file_tbl",
            condition="rag_id = %s",
            params=(kb_id,),
            order_by="upload_time DESC",
            limit=limit,
        )

    def get_file_by_id(self, file_id: int) -> Tuple[ErrorCode, Optional[Dict[str, Any]]]:
        """根据文件ID查询文件记录"""
        err, row = self.mysql.select_one(
            "rag_file_tbl",
            condition="id = %s",
            params=(file_id,),
        )
        return err, row

    def get_file_by_name_and_kb(
        self, file_name: str, kb_id: int
    ) -> Tuple[ErrorCode, Optional[Dict[str, Any]]]:
        """根据文件名和知识库ID查询文件记录"""
        return self.mysql.select_one(
            "rag_file_tbl",
            condition="file_name = %s AND rag_id = %s",
            params=(file_name, kb_id),
        )

    def insert_file_record(self, data: Dict[str, Any]) -> Tuple[ErrorCode, int]:
        """插入一条 rag_file_tbl 文件记录"""
        return self.mysql.insert("rag_file_tbl", data)

    def update_file_record(self, file_id: int, data: Dict[str, Any]) -> Tuple[ErrorCode, int]:
        """按文件ID更新 rag_file_tbl 记录（如 embedding_process、file_embedding_offset 等）"""
        return self.mysql.update(
            "rag_file_tbl", data=data, condition="id = %s", params=(file_id,)
        )

    def list_knowledge_items_by_kb(
        self,
        kb_id: int,
        min_recall_count: Optional[int] = None,
        max_recall_count: Optional[int] = None,
        recent_days: Optional[int] = None,
        sort_by: Optional[str] = None,
        sort_order: str = "desc",
    ) -> Tuple[ErrorCode, List[Dict[str, Any]]]:
        sql = """
SELECT
    id,
    file_name,
    recall_count,
    upload_time
FROM rag_file_tbl
WHERE rag_id = %s AND status = 1 AND embedding_process = 3
"""
        params: list[Any] = [kb_id]
        if min_recall_count is not None:
            sql += " AND recall_count >= %s"
            params.append(int(min_recall_count))
        if max_recall_count is not None:
            sql += " AND recall_count <= %s"
            params.append(int(max_recall_count))
        if recent_days is not None:
            sql += " AND upload_time >= DATE_SUB(NOW(), INTERVAL %s DAY)"
            params.append(int(recent_days))

        if sort_by == "upload_time":
            order_column = "upload_time"
        else:
            order_column = "recall_count"

        direction = "ASC" if sort_order and sort_order.lower() == "asc" else "DESC"

        if order_column == "recall_count":
            sql += f" ORDER BY recall_count {direction}, upload_time DESC"
        else:
            sql += f" ORDER BY upload_time {direction}, recall_count DESC"

        return self.mysql.execute_sql(sql, tuple(params))
