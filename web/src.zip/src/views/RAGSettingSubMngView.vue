<script setup>
import { ref, onMounted, computed } from 'vue'
import { useI18n } from 'vue-i18n'
import { useRagStore } from '@/store/rag'
import { ragApi } from '@/api/rag'
import { KB_TYPES } from '@/store/rag'

const { t } = useI18n()
const ragStore = useRagStore()

const loading = computed(() => ragStore.isLoading)
const list = computed(() => {
  const result = ragStore.knowledgeBases
  console.log('📊 [MngView] list计算属性被调用, ragStore.knowledgeBases:', ragStore.knowledgeBases)
  console.log('📊 [MngView] list计算属性返回值:', result)
  return result
})
const pagination = computed(() => ragStore.pagination)

// 加载知识库列表
async function loadList() {
  try {
    await ragStore.fetchKnowledgeBases()
  } catch (error) {
    console.error('加载知识库列表失败:', error)
  }
}

// 分页处理
function handlePageChange(page) {
  ragStore.setPage(page)
  loadList()
}

onMounted(loadList)

const isFileView = ref(false)
const currentKb = ref(null)
const fileList = ref([])
const knowledgeList = ref([])
const activeDetailTab = ref('file')
const knowledgeTimeFilter = ref('all')
const knowledgeRecallFilter = ref('all')
const knowledgeSort = ref('recall_desc')

async function loadKnowledgeList() {
  if (!currentKb.value) return
  knowledgeList.value = []
  const payload = {
    kb_id: currentKb.value.id
  }
  if (knowledgeTimeFilter.value !== 'all') {
    const map = {
      last7d: 7,
      last30d: 30,
      last90d: 90
    }
    const days = map[knowledgeTimeFilter.value]
    if (days) {
      payload.recent_days = days
    }
  }
  if (knowledgeRecallFilter.value === 'never') {
    payload.max_recall_count = 0
  } else if (knowledgeRecallFilter.value === 'has') {
    payload.min_recall_count = 1
  }
  if (knowledgeSort.value === 'recall_desc') {
    payload.sort_by = 'recall_count'
    payload.sort_order = 'desc'
  } else if (knowledgeSort.value === 'recall_asc') {
    payload.sort_by = 'recall_count'
    payload.sort_order = 'asc'
  } else if (knowledgeSort.value === 'time_desc') {
    payload.sort_by = 'upload_time'
    payload.sort_order = 'desc'
  } else if (knowledgeSort.value === 'time_asc') {
    payload.sort_by = 'upload_time'
    payload.sort_order = 'asc'
  }
  try {
    const resp = await ragApi.getKnowledgeList(payload)
    const data = resp?.data?.data || {}
    const items = data.items || []
    knowledgeList.value = items.map((it) => ({
      id: it.id,
      fileName: it.file_name,
      recallCount: it.recall_count,
      lastAccessTime: it.last_access_time || '-',
      avgScore: it.avg_score ?? '-',
      instructionScore: it.instruction_score ?? '-',
      relevanceScore: it.relevance_score ?? '-',
      isNoise: !!it.is_noise,
      isRedundant: !!it.is_redundant,
      createdAt: it.created_at || '-',
      updatedAt: it.updated_at || '-'
    }))
  } catch (error) {
    console.error('加载知识信息列表失败:', error)
  }
}

async function viewKnowledge(item) {
  currentKb.value = item
  isFileView.value = true
  activeDetailTab.value = 'knowledge'
  knowledgeTimeFilter.value = 'all'
  knowledgeRecallFilter.value = 'all'
  knowledgeSort.value = 'recall_desc'
  await loadKnowledgeList()
}

async function openFileView(item) {
  currentKb.value = item
  isFileView.value = true
  activeDetailTab.value = 'file'
  fileList.value = []
  try {
    const data = await ragStore.exportKnowledgeBase(item.id)
    const files = data?.files || []
    fileList.value = files.map((f) => ({
      id: f.id,
      name: f.file_name,
      status: f.status === 1 ? 'available' : 'disabled',
      uploadTime: f.upload_time ? formatTime(f.upload_time) : '-',
      segmentModel: f.segmentation_type || '-',
      recallCount: f.recall_count ?? 0,
      charCount: f.file_char_count ?? 0,
      progress: f.status === 1 ? 100 : 0
    }))
  } catch (error) {
    console.error('加载知识库文件列表失败:', error)
    alert(`加载知识库文件列表失败：${error.message || '未知错误'}`)
    isFileView.value = false
    currentKb.value = null
  }
}

function backToKbList() {
  isFileView.value = false
  currentKb.value = null
  fileList.value = []
  knowledgeList.value = []
  activeDetailTab.value = 'file'
}

async function onKnowledgeFilterChange() {
  if (activeDetailTab.value !== 'knowledge' || !isFileView.value) return
  await loadKnowledgeList()
}

async function toggleFileEnabled(file) {
  if (file.status === 'generating') return
  if (!currentKb.value) return
  const kbId = currentKb.value.id
  const nextStatusStr = file.status === 'disabled' ? 'available' : 'disabled'
  const nextStatusInt = nextStatusStr === 'available' ? 1 : 0
  try {
    await ragStore.updateFileStatusInKb({
      kbId,
      fileId: file.id,
      status: nextStatusInt
    })
    file.status = nextStatusStr
  } catch (error) {
    console.error('切换文件状态失败:', error)
    alert(`切换文件状态失败：${error.message || '未知错误'}`)
  }
}

async function deleteFile(file) {
  if (!currentKb.value) return
  if (!confirm(t('common.confirmDelete', '确认删除该文件吗？'))) return
  const kbId = currentKb.value.id
  try {
    await ragStore.deleteKbFile({
      kbId,
      fileId: file.id
    })
    fileList.value = fileList.value.filter((f) => f.id !== file.id)
  } catch (error) {
    console.error('删除文件失败:', error)
    alert(`删除文件失败：${error.message || '未知错误'}`)
  }
}

async function downloadFile(file) {
  if (!currentKb.value) return
  const kbId = currentKb.value.id
  try {
    const response = await ragApi.getFileDownloadUrl({
      kb_id: kbId,
      file_id: file.id
    })
    const data = response?.data?.data || {}
    const url = data.url
    if (!url) {
      alert(t('rag.downloadTip', `下载地址获取失败`))
      return
    }
    const a = document.createElement('a')
    a.href = url
    a.download = file.name || data.file_name || ''
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
  } catch (error) {
    console.error('获取文件下载链接失败:', error)
    alert(`获取下载链接失败：${error.message || '未知错误'}`)
  }
}

async function remove(item) {
  if (!confirm(t('rag.confirmDelete', { name: item.name }))) return
  try {
    await ragStore.deleteKnowledgeBase(item.id)
  } catch (error) {
    console.error('删除知识库失败:', error)
    alert(`删除知识库失败：${error.message || '未知错误'}`)
  }
}

async function exportKnowledge(item) {
  try {
    const data = await ragStore.exportKnowledgeBase(item.id)
    if (!data) {
      alert('导出失败：后端未返回数据')
      return
    }
    const blob = new Blob([JSON.stringify(data, null, 2)], {
      type: 'application/json;charset=utf-8'
    })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${item.name || 'knowledge-base'}.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  } catch (error) {
    console.error('导出知识库失败:', error)
    alert(`导出失败：${error.message || '未知错误'}`)
  }
}

async function toggleEnabled(item) {
  const targetStatus = item.status === 'enabled' ? 'disabled' : 'enabled'
  try {
    await ragStore.updateKnowledgeBase({
      id: item.id,
      status: targetStatus
    })
  } catch (error) {
    console.error('切换知识库状态失败:', error)
    alert(`切换状态失败：${error.message || '未知错误'}`)
  }
}

function typeLabel(type) {
  return t(`rag.types.${type}`)
}

function formatTime(timestamp) {
  if (!timestamp) return '-'
  const date = new Date(timestamp)
  return date.toLocaleString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  })
}

function formatFileSize(bytes) {
  if (!bytes || bytes <= 0) return '0 KB'
  const kb = bytes / 1024
  if (kb < 1) {
    return (bytes / 1024).toFixed(2) + ' KB'
  }
  if (kb < 1024) {
    return kb.toFixed(2) + ' KB'
  }
  const mb = kb / 1024
  if (mb < 1024) {
    return mb.toFixed(2) + ' MB'
  }
  const gb = mb / 1024
  return gb.toFixed(2) + ' GB'
}

const showDetail = ref(false)
const isSegmentView = ref(false)
const detailFile = ref(null)
const segments = ref([])

async function openKnowledgeDetail(item) {
  detailFile.value = item
  isSegmentView.value = true
  try {
    segments.value = await ragStore.fetchKnowledgeSegments({
      fileId: item.id,
      pageNo: 1,
      pageSize: 50
    })
  } catch (e) {
    segments.value = []
  }
}

function closeKnowledgeDetail() {
  isSegmentView.value = false
  detailFile.value = null
  segments.value = []
}

// 编辑相关逻辑
const showEdit = ref(false)
const saving = ref(false)
const editForm = ref({
  id: null,
  title: '',
  content: '',
  status: 1
})

function openEdit(seg) {
  editForm.value = {
    id: seg.id,
    title: seg.title || '',
    content: seg.content || '',
    status: seg.status ?? 1
  }
  showEdit.value = true
}

function openCreate() {
  editForm.value = {
    id: null,
    title: '',
    content: '',
    status: 2 // 默认为启用
  }
  showEdit.value = true
}

function cancelEdit() {
  showEdit.value = false
  editForm.value = { id: null, title: '', content: '', status: 1 }
}

async function saveEdit() {
  if (!editForm.value.content.trim()) {
    alert('内容不能为空')
    return
  }
  
  saving.value = true
  try {
    if (editForm.value.id) {
      // 更新
      await ragStore.updateKnowledgeSegment(editForm.value)
      
      // 更新本地列表数据
      const index = segments.value.findIndex(s => s.id === editForm.value.id)
      if (index !== -1) {
        segments.value[index] = {
          ...segments.value[index],
          ...editForm.value,
          updated_at: new Date().toISOString()
        }
      }
    } else {
      // 创建
      if (!detailFile.value) {
        throw new Error('未找到所属文件信息')
      }
      const newSeg = await ragStore.createKnowledgeSegment({
        ...editForm.value,
        file_id: detailFile.value.id
      })
      
      // 添加到本地列表（插在最前）
      // newSeg 应该包含 id
      if (newSeg && newSeg.id) {
        segments.value.unshift({
          ...editForm.value,
          id: newSeg.id,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
          snippet_type: 'text'
        })
      }
    }
    
    showEdit.value = false
  } catch (error) {
    console.error('保存失败:', error)
    alert(`保存失败: ${error.message || '未知错误'}`)
  } finally {
    saving.value = false
  }
}

function getStatusText(status) {
  const map = {
    0: '禁用',
    1: '草稿',
    2: '启用'
  }
  return map[status] ?? '未知'
}

function getStatusClass(status) {
  const map = {
    0: 'status-disabled',
    1: 'status-draft',
    2: 'status-enabled'
  }
  return map[status] ?? ''
}

async function deleteSegment(seg) {
  if (!confirm(t('common.confirmDelete', '确认删除该片段吗？'))) return
  try {
    await ragStore.deleteKnowledgeSegment(seg.id)
    // 更新本地列表数据
    segments.value = segments.value.filter(s => s.id !== seg.id)
  } catch (error) {
    console.error('删除片段失败:', error)
    alert(`删除片段失败: ${error.message || '未知错误'}`)
  }
}

async function toggleSegmentStatus(seg) {
  const nextStatus = seg.status === 2 ? 0 : 2 // 2=启用, 0=禁用 (假设1是草稿)
  try {
    await ragStore.updateKnowledgeSegment({
      id: seg.id,
      status: nextStatus
    })
    seg.status = nextStatus
  } catch (error) {
    console.error('更新片段状态失败:', error)
    alert(`更新状态失败: ${error.message || '未知错误'}`)
  }
}
</script>

<template>
  <div class="rag-mng">
    <!-- 编辑/新建弹窗 -->
    <Teleport to="body">
      <div v-if="showEdit" class="kb-detail-overlay" @click.self="cancelEdit">
        <div class="kb-detail-modal edit-modal">
          <div class="kb-detail-header">
            <div class="kb-detail-title">{{ editForm.id ? '编辑知识片段' : '新增知识片段' }}</div>
            <button type="button" class="btn-secondary" @click="cancelEdit">关闭</button>
          </div>
          <div class="kb-detail-body edit-body">
            <div class="form-item">
              <label>标题</label>
              <input v-model="editForm.title" type="text" placeholder="请输入标题" />
            </div>
            <div class="form-item">
              <label>状态</label>
              <select v-model="editForm.status">
                <option :value="0">禁用</option>
                <option :value="1">草稿</option>
                <option :value="2">启用</option>
              </select>
            </div>
            <div class="form-item flex-1">
              <label>内容</label>
              <textarea v-model="editForm.content" placeholder="请输入内容"></textarea>
            </div>
          </div>
          <div class="kb-detail-footer">
            <button type="button" class="btn-secondary" @click="cancelEdit">取消</button>
            <button type="button" class="btn-primary" :disabled="saving" @click="saveEdit">
              {{ saving ? '保存中...' : '保存' }}
            </button>
          </div>
        </div>
      </div>
    </Teleport>

    <div class="rag-header">
      <div class="rag-desc-wrap">
        <button
          v-if="isFileView"
          type="button"
          class="btn-secondary rag-back-btn"
          :aria-label="t('rag.backToKb')"
          @click="backToKbList"
        >
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="9" />
            <polyline points="13.5 8 9.5 12 13.5 16" />
            <line x1="15" y1="12" x2="9.5" y2="12" />
          </svg>
        </button>
        <span class="rag-desc-icon" aria-hidden="true">ℹ</span>
        <span class="rag-desc">{{ t('rag.fileSupportDesc') }}</span>
      </div>
    </div>

    <div class="rag-table-wrap" v-if="!isFileView">
      <div v-if="loading" class="rag-loading">{{ t('common.loading') }}</div>
      <table v-else class="rag-table rag-kb-table">
        <thead>
          <tr>
            <th>{{ t('rag.columns.name') }}</th>
            <th>{{ t('rag.columns.updatedAt') }}</th>
            <th>{{ t('rag.columns.createdAt') }}</th>
            <th>{{ t('rag.columns.status') }}</th>
            <th>{{ t('rag.columns.totalCapacity') }}</th>
            <th>{{ t('rag.columns.fileCount') }}</th>
            <th class="kb-col-actions">{{ t('rag.columns.actions') }}</th>
          </tr>
        </thead>
        <tbody>
          <tr v-if="list.length === 0">
            <td colspan="6" class="empty-cell">{{ t('common.noData') }}</td>
          </tr>
          <tr v-for="item in list" :key="item.id">
            <td class="col-name">{{ item.name }}</td>
            <td class="col-time">{{ formatTime(item.updated_at) }}</td>
            <td class="col-time">{{ formatTime(item.created_at) }}</td>
            <td class="col-status">
              <span
                class="status-pill"
                :class="{
                  enabled: item.status === 'enabled',
                  generating: item.status === 'generating',
                  disabled: item.status === 'disabled'
                }"
              >
                {{
                  item.status === 'enabled'
                    ? t('rag.statusEnabled', '启用')
                    : item.status === 'generating'
                    ? t('rag.statusGenerating', '正在生成')
                    : t('rag.statusDisabled', '禁用')
                }}
              </span>
            </td>
            <td class="col-capacity">{{ formatFileSize(item.file_capacity) }}</td>
            <td class="col-count">{{ item.file_count ?? 0 }}</td>
            <td class="kb-col-actions">
              <div class="action-group">
                <!-- 查看文件按钮 -->
                <button type="button" class="action-btn" :title="t('rag.viewFiles', '查看文件')" @click="openFileView(item)">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                    <circle cx="12" cy="12" r="3" />
                  </svg>
                  <span class="action-text">{{ t('rag.viewFiles', '查看文件') }}</span>
                </button>

                <!-- 查看知识按钮：跳转到对话页 -->
                <button
                  type="button"
                  class="action-btn"
                  :title="t('rag.viewKnowledge', '查看知识')"
                  @click="viewKnowledge(item)"
                >
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
                    <path d="M4 4.5A2.5 2.5 0 0 0 6.5 7H20" />
                    <path d="M6.5 17V7" />
                    <path d="M20 22V2" />
                  </svg>
                  <span class="action-text">{{ t('rag.viewKnowledge', '查看知识') }}</span>
                </button>

                <!-- 正在生成：只允许查看和删除 -->
                <template v-if="item.status === 'generating'">
                  <button type="button" class="action-btn danger" :title="t('common.delete')" @click="remove(item)">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <polyline points="3 6 5 6 21 6" />
                      <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
                    </svg>
                    <span class="action-text">{{ t('common.delete') }}</span>
                  </button>
                </template>

                <!-- 其他状态：导出 + 启用/禁用 + 删除 -->
                <template v-else>
                  <button type="button" class="action-btn" :title="t('rag.export')" @click="exportKnowledge(item)">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                      <polyline points="17 8 12 3 7 8" />
                      <line x1="12" y1="3" x2="12" y2="15" />
                    </svg>
                    <span class="action-text">{{ t('rag.export', '导出') }}</span>
                  </button>
                  <button
                    type="button"
                    class="action-btn"
                    :title="item.status === 'enabled' ? t('rag.disable') : t('rag.enable')"
                    @click="toggleEnabled(item)"
                  >
                    <svg v-if="item.status === 'enabled'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                      <circle cx="12" cy="12" r="3" />
                    </svg>
                    <svg v-else viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <path
                        d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"
                      />
                      <line x1="1" y1="1" x2="23" y2="23" />
                    </svg>
                    <span class="action-text">{{ item.status === 'enabled' ? t('rag.disable') : t('rag.enable') }}</span>
                  </button>
                  <button type="button" class="action-btn danger" :title="t('common.delete')" @click="remove(item)">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <polyline points="3 6 5 6 21 6" />
                      <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
                    </svg>
                    <span class="action-text">{{ t('common.delete') }}</span>
                  </button>
                </template>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
      
      <!-- 分页组件 -->
      <div class="pagination" v-if="pagination.total > 0">
        <div class="pagination-info">
          <span>共 {{ pagination.total }} 条</span>
          <span>第 {{ pagination.page }}/{{ Math.ceil(pagination.total / pagination.pageSize) }} 页</span>
        </div>
        <div class="pagination-controls">
          <button
            type="button"
            class="btn-secondary"
            :disabled="pagination.page === 1"
            @click="handlePageChange(pagination.page - 1)"
          >
            上一页
          </button>
          <button
            type="button"
            class="btn-secondary"
            :disabled="pagination.page >= Math.ceil(pagination.total / pagination.pageSize)"
            @click="handlePageChange(pagination.page + 1)"
          >
            下一页
          </button>
        </div>
      </div>
    </div>

    <div v-else class="rag-table-wrap">
      <template v-if="activeDetailTab === 'file'">
        <table class="rag-table rag-file-table">
          <thead>
            <tr>
              <th>{{ t('rag.fileColumns.name', '文件名称') }}</th>
              <th>{{ t('rag.fileColumns.status', '文件状态') }}</th>
              <th>{{ t('rag.fileColumns.recallCount', '召回次数') }}</th>
              <th>{{ t('rag.fileColumns.charCount', '字符数') }}</th>
              <th>{{ t('rag.fileColumns.uploadTime', '上传时间') }}</th>
              <th>{{ t('rag.fileColumns.segmentModel', '分段模型') }}</th>
              <th class="file-col-actions">{{ t('rag.fileColumns.actions', '操作') }}</th>
            </tr>
          </thead>
          <tbody>
            <tr v-if="fileList.length === 0">
              <td colspan="7" class="empty-cell">{{ t('common.noData') }}</td>
            </tr>
            <tr v-for="file in fileList" :key="file.id">
              <td class="col-name">{{ file.name }}</td>
              <td>
                <span
                  class="status-pill"
                  :class="{
                    enabled: file.status === 'available',
                    generating: file.status === 'generating',
                    disabled: file.status === 'disabled'
                  }"
                >
                  <template v-if="file.status === 'generating'">
                    {{ t('rag.fileStatusGenerating', '正在生成') }}
                    <span v-if="file.progress !== undefined" class="status-progress">
                      {{ file.progress }}%
                    </span>
                  </template>
                  <template v-else>
                    {{
                      file.status === 'available'
                        ? t('rag.fileStatusAvailable', '可用')
                        : t('rag.fileStatusDisabled', '禁用')
                    }}
                  </template>
                </span>
              </td>
              <td>{{ file.recallCount ?? 0 }}</td>
              <td>{{ file.charCount ?? 0 }}</td>
              <td class="col-time">{{ file.uploadTime }}</td>
              <td>{{ file.segmentModel }}</td>
              <td class="file-col-actions">
                <div class="action-group">
                  <button
                    type="button"
                    class="action-btn"
                    :disabled="file.status === 'generating'"
                    @click="toggleFileEnabled(file)"
                  >
                    <span class="action-text">
                      {{
                        file.status === 'disabled'
                          ? t('rag.enable', '启用')
                          : t('rag.disable', '禁用')
                      }}
                    </span>
                  </button>
                  <button
                    type="button"
                    class="action-btn danger"
                    :disabled="file.status === 'generating'"
                    @click="deleteFile(file)"
                  >
                    <span class="action-text">{{ t('common.delete') }}</span>
                  </button>
                  <button
                    type="button"
                    class="action-btn"
                    :disabled="file.status === 'generating'"
                    @click="downloadFile(file)"
                  >
                    <span class="action-text">{{ t('rag.download', '下载') }}</span>
                  </button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </template>
      <template v-else>
        <!-- 知识片段列表视图 -->
        <template v-if="isSegmentView">
          <div class="rag-files-header">
            <div class="rag-files-title">
              <button
                type="button"
                class="btn-secondary rag-back-btn"
                @click="closeKnowledgeDetail"
              >
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <circle cx="12" cy="12" r="9" />
                  <polyline points="13.5 8 9.5 12 13.5 16" />
                  <line x1="15" y1="12" x2="9.5" y2="12" />
                </svg>
              </button>
              <span class="rag-files-title-text">{{ detailFile?.fileName || '知识详情' }}</span>
              <span class="rag-files-recall-count" v-if="detailFile?.recallCount !== undefined">
                (总召回次数: {{ detailFile.recallCount }})
              </span>
            </div>
            <div class="header-actions">
              <button type="button" class="btn-primary btn-sm" @click="openCreate">新增片段</button>
            </div>
          </div>

          <table class="rag-table">
            <thead>
              <tr>
                <th style="width: 50%">名称/内容</th>
                <th>召回次数</th>
                <th>状态</th>
                <th>更新时间</th>
                <th class="knowledge-col-actions">操作</th>
              </tr>
            </thead>
            <tbody>
              <tr v-if="segments.length === 0">
                <td colspan="5" class="empty-cell">暂无知识片段</td>
              </tr>
              <tr v-for="seg in segments" :key="seg.id">
                <td class="col-name" :title="seg.content">
                  <div class="text-truncate">{{ seg.title || seg.content || seg.summary || '无内容' }}</div>
                </td>
                <td>{{ seg.recall_count ?? 0 }}</td>
                <td>
                  <span
                    class="status-pill"
                    :class="getStatusClass(seg.status)"
                  >
                    {{ getStatusText(seg.status) }}
                  </span>
                </td>
                <td class="col-time">{{ formatTime(seg.updated_at || seg.created_at) }}</td>
                <td class="knowledge-col-actions">
                  <div class="action-group">
                    <button
                      type="button"
                      class="action-btn"
                      @click="toggleSegmentStatus(seg)"
                      :title="seg.status === 2 ? '禁用' : '启用'"
                    >
                      <span class="action-text">{{ seg.status === 2 ? '禁用' : '启用' }}</span>
                    </button>
                    <button type="button" class="action-btn" @click="openEdit(seg)">
                      <span class="action-text">编辑</span>
                    </button>
                    <button type="button" class="action-btn danger" @click="deleteSegment(seg)">
                      <span class="action-text">删除</span>
                    </button>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </template>

        <!-- 知识列表视图 -->
        <template v-else>
          <div class="rag-files-header">
            <div class="rag-files-title">
              <span class="rag-files-title-text">知识信息</span>
              <div class="rag-knowledge-filters">
                <label>
                  时间
                  <select v-model="knowledgeTimeFilter" @change="onKnowledgeFilterChange">
                    <option value="all">全部</option>
                    <option value="last7d">近7天</option>
                    <option value="last30d">近30天</option>
                    <option value="last90d">近90天</option>
                  </select>
                </label>
                <label>
                  召回次数
                  <select v-model="knowledgeRecallFilter" @change="onKnowledgeFilterChange">
                    <option value="all">全部</option>
                    <option value="never">从未召回</option>
                    <option value="has">有召回记录</option>
                  </select>
                </label>
                <label>
                  排序
                  <select v-model="knowledgeSort" @change="onKnowledgeFilterChange">
                    <option value="recall_desc">召回次数从高到低</option>
                    <option value="recall_asc">召回次数从低到高</option>
                    <option value="time_desc">上传时间从近到远</option>
                    <option value="time_asc">上传时间从远到近</option>
                  </select>
                </label>
              </div>
            </div>
          </div>
          <table class="rag-table">
            <thead>
              <tr>
                <th>关联文件名称</th>
                <th>召回次数</th>
                <th>最后检索时间</th>
                <th>平均检索得分</th>
                <th>指令评分</th>
                <th>相关性评分</th>
                <th>是否为噪音</th>
                <th>是否冗余</th>
                <th>创建时间</th>
                <th>更新时间</th>
                <th class="knowledge-col-actions">操作</th>
              </tr>
            </thead>
            <tbody>
              <tr v-if="knowledgeList.length === 0">
                <td colspan="11" class="empty-cell">暂无知识信息</td>
              </tr>
              <tr
                v-for="item in knowledgeList"
                :key="item.id ?? `${item.fileName}-${item.createdAt}`"
              >
                <td class="col-name">{{ item.fileName || '-' }}</td>
                <td>{{ item.recallCount ?? 0 }}</td>
                <td>{{ item.lastAccessTime || '-' }}</td>
                <td>{{ item.avgScore ?? '-' }}</td>
                <td>{{ item.instructionScore ?? '-' }}</td>
                <td>{{ item.relevanceScore ?? '-' }}</td>
                <td>{{ item.isNoise ? '是' : '否' }}</td>
                <td>{{ item.isRedundant ? '是' : '否' }}</td>
                <td>{{ item.createdAt || '-' }}</td>
                <td>{{ item.updatedAt || '-' }}</td>
                <td class="knowledge-col-actions">
                  <div class="action-group">
                    <button type="button" class="action-btn" @click="openKnowledgeDetail(item)">
                      <span class="action-text">查看</span>
                    </button>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </template>
      </template>
    </div>
  </div>
</template>



<style scoped lang="scss">
.rag-mng {
  min-height: 200px;
}

.rag-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  margin-bottom: 16px;
}

.rag-desc-wrap {
  display: flex;
  align-items: center;
  gap: 10px;
  flex: 1;
  min-width: 0;
  padding: 10px 14px;
  background: rgba(var(--accent-rgb, 34 197 94), 0.08);
  border: 1px solid rgba(var(--accent-rgb, 34 197 94), 0.2);
  border-radius: 10px;
}

.rag-desc-icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 22px;
  height: 22px;
  border-radius: 999px;
  background: rgba(34, 197, 94, 0.16);
  color: #22c55e;
  font-size: 0.8rem;
}

.rag-desc {
  font-size: 0.85rem;
  color: var(--text-secondary);
}

.btn-secondary {
  padding: 8px 14px;
  border-radius: 999px;
  border: 1px solid var(--border-primary);
  background: var(--bg-tertiary);
  color: var(--text-secondary);
  font-size: 0.85rem;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  transition: all 0.2s ease;

  &:hover {
    background: var(--bg-hover);
    color: var(--text-primary);
  }
}

.rag-table-wrap {
  border-radius: 14px;
  border: 1px solid var(--border-primary);
  background: var(--bg-tertiary);
  overflow: hidden;
}

.kb-detail-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.45);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 2000;
}

.kb-detail-modal {
  width: 820px;
  max-height: 80vh;
  background: var(--bg-secondary);
  border: 1px solid var(--border-primary);
  border-radius: 12px;
  overflow: hidden;
  display: flex;
  flex-direction: column;
}

.kb-detail-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 16px;
  border-bottom: 1px solid var(--border-primary);
}

.header-actions {
  display: flex;
  align-items: center;
  gap: 8px;
}

.btn-sm {
  padding: 4px 10px;
  font-size: 0.8rem;
}

.kb-detail-title {
  font-size: 16px;
  color: var(--text-primary);
  font-weight: 600;
}

.kb-detail-body {
  padding: 12px 16px;
  overflow: auto;
}

.segment-list {
  display: grid;
  gap: 10px;
}

.segment-card {
  border: 1px solid var(--border-primary);
  border-radius: 10px;
  padding: 12px;
  background: var(--bg-tertiary);
}

.segment-title {
  font-weight: 600;
  color: var(--text-primary);
  margin-bottom: 6px;
}

.segment-meta {
  margin-left: 8px;
  color: var(--text-muted);
  font-size: 12px;
}

.segment-summary {
  color: var(--text-secondary);
  font-size: 0.9rem;
}

.segment-empty {
  color: var(--text-secondary);
  padding: 16px 8px;
}


.rag-loading {
  padding: 40px 24px;
  text-align: center;
  font-size: 0.9rem;
  color: var(--text-secondary);
}

.rag-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 0.85rem;
}

.rag-table thead {
  background: rgba(15, 23, 42, 0.8);
}

.rag-table th,
.rag-table td {
  padding: 10px 14px;
  text-align: left;
}

.rag-table th {
  font-weight: 500;
  color: var(--text-muted);
  border-bottom: 1px solid var(--border-primary);
}

.rag-table tbody tr:nth-child(even) {
  background: rgba(15, 23, 42, 0.6);
}

.rag-table tbody tr:hover {
  background: rgba(15, 23, 42, 0.9);
}

.kb-col-actions {
  width: 480px;
}

.file-col-actions {
  width: 300px;
}

.knowledge-col-actions {
  width: 240px;
}

.empty-cell {
  text-align: center;
  color: var(--text-secondary);
  padding: 32px 12px;
}

.action-group {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  flex-wrap: nowrap;
}

.action-btn {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 4px 8px;
  border-radius: 999px;
  border: 1px solid transparent;
  background: transparent;
  color: var(--text-secondary);
  font-size: 0.8rem;
  cursor: pointer;
  transition: all 0.2s ease;
  margin-right: 6px;

  svg {
    width: 14px;
    height: 14px;
  }

  &:hover {
    border-color: var(--border-primary);
    background: var(--bg-hover);
    color: var(--text-primary);
  }

  &.danger:hover {
    border-color: rgba(248, 113, 113, 0.6);
    color: #f97373;
  }
}

.col-name {
  max-width: 260px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.col-time,
.col-capacity,
.col-count {
  white-space: nowrap;
}

.status-progress {
  margin-left: 4px;
  font-size: 0.8em;
  opacity: 0.85;
}

.rag-files-header {
  padding: 12px 16px 0;
}

.rag-files-title {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 8px;
}

.rag-files-title-text {
  font-size: 0.9rem;
  color: var(--text-secondary);
}

.rag-files-recall-count {
  font-size: 0.85rem;
  color: var(--text-muted);
  margin-left: 4px;
}

.rag-back-btn {
  padding: 4px;

  svg {
    width: 22px;
    height: 22px;
  }
}

.rag-knowledge-filters {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-left: auto;
}

.rag-knowledge-filters select {
  margin-left: 4px;
  padding: 4px 8px;
  border-radius: 999px;
  border: 1px solid var(--border-primary);
  background: var(--bg-secondary);
  color: var(--text-secondary);
  font-size: 0.8rem;
}

.pagination {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  margin-top: 16px;
  padding: 12px 16px;
  background: var(--bg-secondary);
  border-radius: 8px;
}

.pagination-info {
  display: flex;
  align-items: center;
  gap: 16px;
  font-size: 0.875rem;
  color: var(--text-secondary);
}

.pagination-controls {
  display: flex;
  align-items: center;
  gap: 8px;

  button {
    padding: 6px 12px;
    font-size: 0.875rem;
    min-width: 80px;

    &:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }
  }
}

.segment-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 6px;
}

.segment-status {
  font-size: 0.8rem;
  padding: 2px 8px;
  border-radius: 4px;
}

.status-disabled {
  background: rgba(var(--text-secondary-rgb, 156 163 175), 0.1);
  color: var(--text-secondary);
}

.status-draft {
  background: rgba(var(--accent-rgb, 34 197 94), 0.1);
  color: #fbbf24;
}

.status-enabled {
  background: rgba(var(--accent-rgb, 34 197 94), 0.1);
  color: #22c55e;
}

.segment-footer {
  margin-top: 8px;
  text-align: right;
}

.btn-text {
  background: none;
  border: none;
  color: var(--accent-color, #22c55e);
  cursor: pointer;
  font-size: 0.85rem;
  padding: 4px 8px;
  
  &:hover {
    text-decoration: underline;
  }
}

.btn-text.danger {
  color: #ef4444;
  
  &:hover {
    color: #dc2626;
  }
}

.edit-modal {
  width: 600px;
  height: 600px;
}

.edit-body {
  display: flex;
  flex-direction: column;
  gap: 16px;
  height: 100%;
}

.form-item {
  display: flex;
  flex-direction: column;
  gap: 6px;
  
  label {
    font-size: 0.9rem;
    color: var(--text-secondary);
  }
  
  input, select, textarea {
    padding: 8px 12px;
    border-radius: 6px;
    border: 1px solid var(--border-primary);
    background: var(--bg-tertiary);
    color: var(--text-primary);
    font-size: 0.9rem;
    
    &:focus {
      outline: none;
      border-color: var(--accent-color, #22c55e);
    }
  }
  
  textarea {
    flex: 1;
    resize: none;
    min-height: 200px;
  }
}

.flex-1 {
  flex: 1;
  min-height: 0;
}

.kb-detail-footer {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  padding: 14px 16px;
  border-top: 1px solid var(--border-primary);
}

.btn-primary {
  padding: 8px 16px;
  border-radius: 999px;
  border: none;
  background: var(--accent-color, #22c55e);
  color: #fff;
  font-size: 0.85rem;
  cursor: pointer;
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
  
  &:hover:not(:disabled) {
    opacity: 0.9;
  }
}
</style>
